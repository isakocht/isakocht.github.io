# Rezeptbuch aufs iPhone (und Android) bringen, kostenlos

Die App ist eine Web-App. Sie liegt einmal im Internet auf einer kostenlosen Seite, und du legst sie dir aufs iPhone wie eine normale App. Danach läuft sie offline, mit eigenem Icon, im Vollbild. Es kostet nichts, und du brauchst keinen Computer-Fachmann. Du brauchst nur einen Computer mit Browser für die einmalige Einrichtung, danach nur noch das Handy.

Zeitaufwand: etwa 20 Minuten.

## Was du bekommst

Eine Datei `rezeptbuch-website.zip`. Darin sind die fertigen Dateien der App (etwa 25 Dateien, 15 MB). Die lädst du einmal auf GitHub Pages hoch, einen kostenlosen Dienst, der Webseiten ins Internet stellt.

## Teil 1: GitHub-Konto anlegen (einmalig)

1. Geh am Computer auf **https://github.com** und klick oben rechts auf **Sign up**.
2. Gib eine E-Mail-Adresse ein, wähle ein Passwort und einen **Benutzernamen**. Der Benutzername wird Teil deiner Web-Adresse, also z. B. `pau-kocht`. Nur Kleinbuchstaben, Zahlen und Bindestriche. **Merk dir den Benutzernamen genau**, du brauchst ihn gleich.
3. Bestätige die E-Mail, die GitHub dir schickt. Der kostenlose Plan („Free“) reicht.

## Teil 2: Die Seite anlegen

4. Nach dem Einloggen klick oben rechts auf das **+** und dann auf **New repository**.
5. Bei **Repository name** trag genau das ein: dein Benutzername, dann `.github.io`. Beispiel: heißt du `pau-kocht`, dann heißt das Repository `pau-kocht.github.io`. Das ist wichtig, genau so entsteht später deine Web-Adresse.
6. Lass **Public** ausgewählt (Private funktioniert im kostenlosen Plan nicht mit Webseiten). Im Code der App stecken keine persönlichen Daten, deine Rezepte bleiben sowieso nur auf deinem Handy.
7. Setz den Haken bei **Add a README file**. Klick unten auf **Create repository**.

## Teil 3: Die App-Dateien hochladen

8. Entpacke `rezeptbuch-website.zip` am Computer (Doppelklick). Du bekommst einen Ordner `rezeptbuch-website` mit `index.html`, `sw.js`, den Ordnern `assets`, `icons`, `tess` usw.
9. Auf der GitHub-Seite deines Repositories klick auf **Add file** (oben, neben dem grünen Button) und dann **Upload files**.
10. Öffne den entpackten Ordner am Computer, markiere **alles darin** (Strg+A bzw. cmd+A, also die Dateien UND die Ordner) und zieh es mit der Maus in das Feld „Drag files here“ auf der GitHub-Seite. Warte, bis alle Dateien in der Liste stehen (die Ordner `assets`, `icons`, `tess` müssen dabei sein).
    Falls dein Browser die Ordner nicht mitnimmt: nutze Google Chrome, der kann Ordner per Drag & Drop hochladen.
11. Scroll nach unten und klick auf **Commit changes**. Das Hochladen dauert etwa eine Minute.

## Teil 4: Webseite einschalten

12. Klick oben im Repository auf **Settings** (Zahnrad-Reiter), dann links auf **Pages**.
13. Unter **Build and deployment** bei **Source** muss **Deploy from a branch** stehen. Bei **Branch** wähle **main** und daneben **/ (root)**, dann **Save**.
14. Warte 1 bis 3 Minuten, lade die Seite neu. Oben erscheint dann: „Your site is live at https://DEIN-NAME.github.io/“. Klick den Link an, die App sollte im Browser erscheinen. Wenn noch „404“ kommt, ein paar Minuten warten und neu laden.

## Teil 5: Aufs iPhone

15. Öffne auf dem iPhone **Safari** (es muss Safari sein, nicht Chrome) und gib deine Adresse ein: `https://DEIN-NAME.github.io`
16. Tipp unten in der Mitte auf **Teilen** (das Quadrat mit Pfeil nach oben).
17. Scroll in der Liste nach unten und tipp auf **Zum Home-Bildschirm**, dann oben rechts **Hinzufügen**.
18. Auf dem Home-Bildschirm liegt jetzt „Rezeptbuch“ mit eigenem Icon. Ab jetzt immer darüber öffnen, nicht über Safari. Beim ersten Öffnen einmal kurz online bleiben (die Texterkennung lädt ihre Daten, etwa 15 MB), danach funktioniert alles auch ohne Internet.
19. Beim ersten Foto fragt das iPhone nach Kamera- bzw. Fotozugriff, das erlauben.

## Android

Gleiche Adresse in **Chrome** öffnen, Menü (⋮) oben rechts, **App installieren** oder **Zum Startbildschirm hinzufügen**. Fertig.

## Gut zu wissen

- **Deine Rezepte bleiben auf dem Handy**, nicht im Internet. GitHub liefert nur die App aus, es sieht deine Daten nie. Deshalb: **Löschst du das App-Icon vom Home-Bildschirm, sind die Rezepte weg.** Mach unter „Mehr“ regelmäßig ein Backup (das ist eine kleine Datei, die du dir z. B. per Mail schicken kannst).
- **iPhone ↔ Android** abgleichen: Backup exportieren, an das andere Handy schicken, dort importieren.
- **Updates**: Wenn ich die App verbessere, bekommst du ein neues ZIP. Dann Teil 3 wiederholen (Dateien hochladen, gleiche Namen werden ersetzt), die App auf dem Handy zwei Mal öffnen, fertig.
- **Ohne GitHub**: Alternativ geht auch **https://app.netlify.com/drop**, dort den entpackten Ordner reinziehen (kostenloses Konto nötig). Die Adresse ist dann etwas kryptischer, funktioniert aber genauso.
