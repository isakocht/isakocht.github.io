# Rezeptbuch (Web-App / PWA)

Privates Rezeptbuch für iPhone und Android als installierbare Web-App. Foto rein, Rezept raus: Texterkennung mit Tesseract.js komplett im Browser, regelbasierter Parser für Titel, Zutaten, Schritte, Zeiten, Mahlzeit-Typen und Keywords, Speicherung in IndexedDB auf dem Gerät. Läuft offline.

Für die Installation ohne Technikkenntnisse siehe **ANLEITUNG.md**.

## Entwicklung

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # Parser- und Such-Tests
npm run build      # fertige Dateien in dist/
```

`dist/` ist alles, was gehostet werden muss (statische Dateien, kein Server). Die Seite muss über **https** laufen, sonst gibt es keinen Service Worker und keine Home-Bildschirm-Installation. GitHub Pages, Netlify, Cloudflare Pages usw. erfüllen das.

`vite.config.ts` hat `base: '/'`. Liegt die App in einem Unterpfad (z. B. `https://name.github.io/rezeptbuch/`), dort `base: '/rezeptbuch/'` eintragen und neu bauen.

## Struktur

```
src/lib/types.ts       Datenmodell
src/lib/knowledge.ts   Wörterbücher: Zutaten-Gruppen, Synonyme, Gerichte-Regeln, Keyword-Regeln
src/lib/parser.ts      OCR-Text → Rezeptentwurf
src/lib/search.ts      Suche mit Synonym-Erweiterung, Inhaltsverzeichnis
src/lib/ocr.ts         Bildvorverarbeitung (Canvas) + Tesseract-Worker
src/lib/db.ts          IndexedDB (idb), Bilder als Blob, Export/Import
src/lib/store.tsx      React-Context, Hash-Router, Bild-URLs
src/ui/               Screens und Komponenten
public/tess/           Tesseract-Worker, WASM-Cores, Sprachdaten deu+eng (tessdata_fast)
__tests__/             Jest-Tests
```

## Erkennung verbessern

Alles Regelwerk steht in `src/lib/knowledge.ts` (Gruppen, Synonyme, `MEAL_RULES`, `KEYWORD_RULES`). Nach Änderungen `npm test`.

Die Sprachdaten sind die schnellen Modelle (`tessdata_fast`). Für höhere Genauigkeit bei schlechten Fotos können die `tessdata_best`-Dateien nach `public/tess/` gelegt werden (größer und langsamer).
