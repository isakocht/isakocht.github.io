import type { ReactNode } from 'react';
import type { MealType, Recipe } from '../lib/types';

/* Kleine Inline-Icons (Ionicons-Stil, MIT), damit keine Icon-Bibliothek nötig ist. */
const paths: Record<string, string> = {
  book: 'M256 160c16-63 64-95 128-95 45 0 80 12 96 19v322c-16-7-51-19-96-19-64 0-112 32-128 96-16-64-64-96-128-96-45 0-80 12-96 19V84c16-7 51-19 96-19 64 0 112 32 128 95Zm0 0v323',
  search: 'M221 68a153 153 0 1 0 0 306 153 153 0 1 0 0-306Zm117 250 106 106',
  camera: 'M350 96h-18l-15-38a14 14 0 0 0-13-9h-96a14 14 0 0 0-13 9l-15 38h-18C96 96 64 128 64 192v160c0 64 32 96 96 96h192c64 0 96-32 96-96V192c0-64-32-96-96-96Zm-94 288a80 80 0 1 1 0-160 80 80 0 1 1 0 160Z',
  more: 'M256 48a208 208 0 1 0 0 416 208 208 0 1 0 0-416Zm-96 234a26 26 0 1 1 0-52 26 26 0 1 1 0 52Zm96 0a26 26 0 1 1 0-52 26 26 0 1 1 0 52Zm96 0a26 26 0 1 1 0-52 26 26 0 1 1 0 52Z',
  hand: 'M80 320V144a32 32 0 0 1 64 0v128M144 256V96a32 32 0 0 1 64 0v144M208 240V80a32 32 0 0 1 64 0v192M272 272V128a32 32 0 0 1 64 0v176M336 304l40-56a32 32 0 0 1 48 40l-72 120c-24 40-56 72-136 72-88 0-136-64-136-160',
  hourglass: 'M160 48h192M160 464h192M352 48c0 96-32 128-96 176 64 48 96 80 96 176M160 48c0 96 32 128 96 176-64 48-96 80-96 176',
  clock: 'M256 64a192 192 0 1 0 0 384 192 192 0 1 0 0-384Zm0 96v112h96',
  people: 'M336 256a80 80 0 1 0 0-160 80 80 0 1 0 0 160Zm0 32c-72 0-144 40-144 112v32h288v-32c0-72-72-112-144-112ZM160 288a64 64 0 1 0 0-128 64 64 0 1 0 0 128Zm0 32c-64 0-128 32-128 96v32h96',
  check: 'M416 128 192 384l-96-96',
  checkbox: 'M400 48H112a64 64 0 0 0-64 64v288a64 64 0 0 0 64 64h288a64 64 0 0 0 64-64V112a64 64 0 0 0-64-64Zm-32 128L224 352l-80-80',
  square: 'M416 448H96a32 32 0 0 1-32-32V96a32 32 0 0 1 32-32h320a32 32 0 0 1 32 32v320a32 32 0 0 1-32 32Z',
  edit: 'M384 224v184a40 40 0 0 1-40 40H104a40 40 0 0 1-40-40V168a40 40 0 0 1 40-40h167M459 80l-26-26a20 20 0 0 0-29 0L216 242l-14 68 68-14 188-188a20 20 0 0 0 1-28Z',
  trash: 'M112 112l20 320c1 17 15 32 32 32h184c17 0 31-15 32-32l20-320M80 112h352M192 112V72a24 24 0 0 1 24-24h80a24 24 0 0 1 24 24v40M256 176v224M184 176l8 224M328 176l-8 224',
  image: 'M416 64H96a64 64 0 0 0-64 64v256a64 64 0 0 0 64 64h320a64 64 0 0 0 64-64V128a64 64 0 0 0-64-64ZM336 192a32 32 0 1 1 0-64 32 32 0 1 1 0 64ZM48 368l128-128 96 96 64-64 128 128',
  images: 'M432 112V96a48 48 0 0 0-48-48H64a48 48 0 0 0-48 48v256a48 48 0 0 0 48 48h16M448 112H128a48 48 0 0 0-48 48v256a48 48 0 0 0 48 48h320a48 48 0 0 0 48-48V160a48 48 0 0 0-48-48ZM144 400l96-96 64 64 64-64 96 96',
  sparkle: 'M259 104l30 87 87 30-87 30-30 87-30-87-87-30 87-30ZM120 380l12 36 36 12-36 12-12 36-12-36-36-12 36-12ZM400 40l8 24 24 8-24 8-8 24-8-24-24-8 24-8Z',
  share: 'M336 192h40a40 40 0 0 1 40 40v192a40 40 0 0 1-40 40H136a40 40 0 0 1-40-40V232a40 40 0 0 1 40-40h40M336 128l-80-80-80 80M256 48v288',
  download: 'M336 176h40a40 40 0 0 1 40 40v192a40 40 0 0 1-40 40H136a40 40 0 0 1-40-40V216a40 40 0 0 1 40-40h40M176 272l80 80 80-80M256 48v304',
  close: 'M368 368 144 144M368 144 144 368',
  back: 'M244 400 100 256l144-144M120 256h292',
  alert: 'M256 80 32 464h448ZM256 208v112M256 384h.1',
  filter: 'M32 144h448M96 256h320M192 368h128',
  plus: 'M256 112v288M112 256h288',
  flame: 'M256 48c16 80 96 112 96 208a96 96 0 0 1-192 0c0-40 16-64 32-88 0 40 16 56 32 56 24 0 32-32 32-176Z',
};

export function Icon({ name, size = 22, filled = false }: { name: keyof typeof paths | string; size?: number; filled?: boolean }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={32} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={paths[name] ?? ''} />
    </svg>
  );
}

export function formatMinutes(min: number | null): string {
  if (min == null) return '–';
  if (min < 60) return `${min} Min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m === 0 ? `${h} Std` : `${h} Std ${m} Min`;
}

export function MealChip({ meal, on = true, onClick, small }: { meal: MealType; on?: boolean; onClick?: () => void; small?: boolean }) {
  const cls = `chip meal-${meal} ${on ? 'on' : ''} ${small ? 'small' : ''}`;
  return onClick ? (
    <button type="button" className={cls} onClick={onClick}>
      {meal}
    </button>
  ) : (
    <span className={cls}>{meal}</span>
  );
}

export function KeywordChip({ label, selected, onClick, onRemove, small }: { label: string; selected?: boolean; onClick?: () => void; onRemove?: () => void; small?: boolean }) {
  const cls = `chip kw ${selected ? 'selected' : ''} ${small ? 'small' : ''}`;
  const inner = (
    <>
      {label}
      {onRemove && (
        <span className="x" onClick={(e) => { e.stopPropagation(); onRemove(); }} role="button" aria-label="Entfernen">
          <Icon name="close" size={14} />
        </span>
      )}
    </>
  );
  return onClick ? (
    <button type="button" className={cls} onClick={onClick}>
      {inner}
    </button>
  ) : (
    <span className={cls}>{inner}</span>
  );
}

export function Durations({ r, compact }: { r: Pick<Recipe, 'activeMinutes' | 'passiveMinutes' | 'totalMinutes'>; compact?: boolean }) {
  const items = [
    { icon: 'hand', label: 'Aktiv', v: r.activeMinutes },
    { icon: 'hourglass', label: 'Inaktiv', v: r.passiveMinutes },
    { icon: 'clock', label: 'Gesamt', v: r.totalMinutes },
  ];
  return (
    <div className={`durations ${compact ? 'compact' : ''}`}>
      {items.map((it) => (
        <span className="item" key={it.label} title={it.label}>
          <Icon name={it.icon} size={16} />
          <b>{formatMinutes(it.v)}</b>
          {!compact && <span>{it.label}</span>}
        </span>
      ))}
    </div>
  );
}

export function RecipeCard({ r, onClick }: { r: Recipe; onClick: () => void }) {
  return (
    <button type="button" className="card" onClick={onClick}>
      <div className="title">{r.title || 'Unbenanntes Rezept'}</div>
      {r.mealTypes.length > 0 && (
        <div className="chips">
          {r.mealTypes.map((m) => (
            <MealChip key={m} meal={m} small />
          ))}
        </div>
      )}
      <Durations r={r} compact />
      {r.ingredients.length > 0 && <div className="ings">{r.ingredients.map((i) => i.name).join(' · ')}</div>}
    </button>
  );
}

export function Section({ title, right, children }: { title: string; right?: ReactNode; children?: ReactNode }) {
  return (
    <section className="section">
      <div className="section-head">
        <h3>{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}

export function Button({ children, icon, variant = '', onClick, disabled, type = 'button' }: { children: ReactNode; icon?: string; variant?: '' | 'secondary' | 'ghost' | 'danger'; onClick?: () => void; disabled?: boolean; type?: 'button' | 'submit' }) {
  return (
    <button type={type} className={`btn ${variant}`} onClick={onClick} disabled={disabled}>
      {icon && <Icon name={icon} size={20} />}
      {children}
    </button>
  );
}

export function Empty({ icon, title, text }: { icon: string; title: string; text?: string }) {
  return (
    <div className="empty">
      <Icon name={icon} size={48} />
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  );
}
