import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import { prepareImage, recognizeText, warmUp } from '../lib/ocr';
import { parseRecipeText } from '../lib/parser';
import { setPendingDraft } from '../lib/store';
import { saveImage } from '../lib/db';
import { emptyDraft } from '../lib/types';
import { Button, Icon } from './components';

type Phase = 'idle' | 'working' | 'done';

const STATUS_DE: Record<string, string> = {
  'loading tesseract core': 'Erkennung wird geladen …',
  'initializing tesseract': 'Erkennung wird gestartet …',
  'loading language traineddata': 'Sprachdaten werden geladen …',
  'initializing api': 'Fast fertig …',
  'recognizing text': 'Text wird gelesen …',
};

/**
 * Scannen: Foto (Kamera) oder Galerie → Vorverarbeitung → Tesseract → Parser → Editor.
 * Mehrere Fotos nacheinander möglich (z. B. zwei Buchseiten), Text wird zusammengeführt.
 */
export function ScanScreen({ toEditor, toast }: { toEditor: () => void; toast: (s: string) => void }) {
  const camRef = useRef<HTMLInputElement>(null);
  const galRef = useRef<HTMLInputElement>(null);
  const [phase, setPhase] = useState<Phase>('idle');
  const [text, setText] = useState('');
  const [images, setImages] = useState<{ ref: string; url: string }[]>([]);
  const [status, setStatus] = useState('');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    warmUp();
    return () => images.forEach((i) => URL.revokeObjectURL(i.url));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onFiles(e: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (files.length === 0) return;
    setPhase('working');
    let merged = text;
    try {
      for (let i = 0; i < files.length; i++) {
        setStatus(files.length > 1 ? `Bild ${i + 1} von ${files.length} wird vorbereitet …` : 'Bild wird vorbereitet …');
        setProgress(0);
        const { ocrCanvas, thumbnail } = await prepareImage(files[i]);
        const ref = await saveImage(thumbnail);
        setImages((cur) => [...cur, { ref, url: URL.createObjectURL(thumbnail) }]);
        const t = await recognizeText(ocrCanvas, (st, p) => {
          setStatus(STATUS_DE[st] ?? st);
          setProgress(st === 'recognizing text' ? p : 0);
        });
        merged = merged ? `${merged}\n${t}` : t;
        setText(merged);
      }
      setPhase('done');
    } catch (err) {
      console.error(err);
      toast(`Erkennung fehlgeschlagen: ${(err as Error).message}`);
      setPhase(images.length ? 'done' : 'idle');
    }
  }

  function createRecipe() {
    const draft = text.trim() ? parseRecipeText(text) : emptyDraft();
    draft.imageUri = images[0]?.ref ?? null;
    setPendingDraft(draft);
    reset(false);
    toEditor();
  }

  function manual() {
    setPendingDraft(emptyDraft());
    toEditor();
  }

  function reset(ask: boolean) {
    if (ask && images.length && !confirm('Fotos und erkannten Text verwerfen?')) return;
    setImages([]);
    setText('');
    setPhase('idle');
    setProgress(0);
  }

  return (
    <div className="screen">
      <div className="topbar">
        <span className="title">Scannen</span>
      </div>
      {phase === 'idle' && (
        <div className="hero">
          <Icon name="camera" size={64} />
          <h2>Rezept einlesen</h2>
          <p>Fotografiere eine Buchseite, einen handgeschriebenen Zettel oder wähle einen Screenshot aus der Galerie. Der Text wird direkt auf dem Gerät erkannt, nichts verlässt dein Handy.</p>
        </div>
      )}

      {images.length > 0 && (
        <div className="thumbs">
          {images.map((i) => (
            <img key={i.ref} src={i.url} alt="" />
          ))}
        </div>
      )}

      <div className="stack">
        <Button icon="camera" onClick={() => camRef.current?.click()} disabled={phase === 'working'}>
          {images.length ? 'Weitere Seite fotografieren' : 'Foto aufnehmen'}
        </Button>
        <Button icon="images" variant="secondary" onClick={() => galRef.current?.click()} disabled={phase === 'working'}>
          {images.length ? 'Weitere aus Galerie' : 'Aus Galerie wählen'}
        </Button>
        <input ref={camRef} type="file" accept="image/*" capture="environment" className="hidden-input" onChange={onFiles} />
        <input ref={galRef} type="file" accept="image/*" multiple className="hidden-input" onChange={onFiles} />
      </div>

      {phase === 'working' && (
        <>
          <div className="progress">
            <div style={{ width: `${Math.round(progress * 100)}%` }} />
          </div>
          <div className="status">{status}</div>
        </>
      )}

      {phase === 'done' && (
        <>
          <div className="section-head" style={{ marginTop: 24 }}>
            <h3>Erkannter Text</h3>
          </div>
          <div className="box">
            <pre className="ocr">{text.trim() || 'Kein Text erkannt. Du kannst das Rezept trotzdem manuell anlegen.'}</pre>
          </div>
          <div className="stack" style={{ marginTop: 12 }}>
            <Button icon="sparkle" onClick={createRecipe}>
              Rezept daraus erstellen
            </Button>
            <Button variant="ghost" onClick={() => reset(true)}>
              Verwerfen
            </Button>
          </div>
        </>
      )}

      {phase === 'idle' && (
        <div style={{ marginTop: 16 }}>
          <Button variant="ghost" icon="edit" onClick={manual}>
            Ohne Foto manuell anlegen
          </Button>
        </div>
      )}
    </div>
  );
}
