import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { takePendingDraft, useImageUrl, useRecipes } from '../lib/store';
import { computeTotal, emptyDraft, MEAL_TYPES, type Ingredient, type MealType, type RecipeDraft } from '../lib/types';
import { inferKeywords, inferMealTypes, parseIngredientLine } from '../lib/parser';
import { prepareImage } from '../lib/ocr';
import { saveImage } from '../lib/db';
import { Button, Icon, KeywordChip, MealChip, Section } from './components';

/** Editor für neue (id = "new") und bestehende Rezepte. */
export function EditScreen({ id, back, done, toast }: { id: string; back: () => void; done: (id: string) => void; toast: (s: string) => void }) {
  const isNew = id === 'new';
  const { byId, create, update, loading } = useRecipes();

  const initial = useMemo<RecipeDraft | null>(() => {
    if (isNew) return takePendingDraft() ?? emptyDraft();
    const r = byId(id);
    if (!r) return null;
    const { id: _i, createdAt: _c, updatedAt: _u, ...d } = r;
    void _i; void _c; void _u;
    return d;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isNew, loading]);

  if (!initial) {
    return (
      <div className="screen no-tabs">
        <div className="topbar">
          <button type="button" className="link" onClick={back}>
            <Icon name="back" size={20} /> Zurück
          </button>
        </div>
        {!loading && <p className="muted">Rezept nicht gefunden.</p>}
      </div>
    );
  }
  return <EditForm key={id} initial={initial} isNew={isNew} back={back} done={done} toast={toast} save={(d) => (isNew ? create(d).then((r) => r.id) : update(id, d).then(() => id))} />;
}

function EditForm({ initial, isNew, back, done, toast, save }: { initial: RecipeDraft; isNew: boolean; back: () => void; done: (id: string) => void; toast: (s: string) => void; save: (d: RecipeDraft) => Promise<string> }) {
  const [title, setTitle] = useState(initial.title);
  const [ingText, setIngText] = useState(initial.ingredients.map((i) => [i.amount, i.name].filter(Boolean).join(' ')).join('\n'));
  const [stepsText, setStepsText] = useState(initial.steps.join('\n\n'));
  const [active, setActive] = useState(initial.activeMinutes?.toString() ?? '');
  const [passive, setPassive] = useState(initial.passiveMinutes?.toString() ?? '');
  const [total, setTotal] = useState(initial.totalMinutes?.toString() ?? '');
  const [totalTouched, setTotalTouched] = useState(false);
  const [servings, setServings] = useState(initial.servings ?? '');
  const [meals, setMeals] = useState<MealType[]>(initial.mealTypes);
  const [keywords, setKeywords] = useState<string[]>(initial.keywords);
  const [newKw, setNewKw] = useState('');
  const [notes, setNotes] = useState(initial.notes);
  const [imageRef, setImageRef] = useState<string | null>(initial.imageUri);
  const [saving, setSaving] = useState(false);
  const imgUrl = useImageUrl(imageRef);
  const fileRef = useRef<HTMLInputElement>(null);

  const num = (s: string) => {
    const n = parseInt(s.replace(/\D/g, ''), 10);
    return Number.isFinite(n) ? n : null;
  };

  useEffect(() => {
    if (totalTouched) return;
    const t = computeTotal(num(active), num(passive), null);
    setTotal(t == null ? '' : String(t));
  }, [active, passive, totalTouched]);

  const parsedIngredients = (): Ingredient[] => ingText.split('\n').map((l) => l.trim()).filter(Boolean).map(parseIngredientLine);
  const parsedSteps = (): string[] =>
    stepsText
      .split(/\n\s*\n|\n(?=\d{1,2}[.)]\s)/)
      .map((s) => s.replace(/^\d{1,2}[.)]\s+/, '').trim())
      .filter(Boolean);

  const toggleMeal = (m: MealType) => setMeals((c) => (c.includes(m) ? c.filter((x) => x !== m) : [...c, m]));
  const addKw = () => {
    const k = newKw.trim();
    if (k && !keywords.some((x) => x.toLowerCase() === k.toLowerCase())) setKeywords([...keywords, k]);
    setNewKw('');
  };
  const suggest = () => {
    const ings = parsedIngredients();
    const steps = parsedSteps();
    const kw = inferKeywords(title, ings, steps, meals);
    const ml = inferMealTypes(title, kw, ings, steps);
    setKeywords((c) => Array.from(new Set([...c, ...kw])));
    setMeals((c) => Array.from(new Set([...c, ...ml])));
  };

  async function onImage(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    try {
      const { thumbnail } = await prepareImage(f);
      setImageRef(await saveImage(thumbnail));
    } catch (err) {
      toast(`Bild konnte nicht übernommen werden: ${(err as Error).message}`);
    }
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return toast('Gib dem Gericht einen Namen.');
    setSaving(true);
    const a = num(active);
    const p = num(passive);
    try {
      const id = await save({
        title: title.trim(),
        ingredients: parsedIngredients(),
        steps: parsedSteps(),
        activeMinutes: a,
        passiveMinutes: p,
        totalMinutes: computeTotal(a, p, totalTouched ? num(total) : null),
        servings: servings.trim() || null,
        mealTypes: MEAL_TYPES.filter((m) => meals.includes(m)),
        keywords,
        sourceText: initial.sourceText,
        imageUri: imageRef,
        notes,
      });
      done(id);
    } catch (err) {
      toast(`Speichern fehlgeschlagen: ${(err as Error).message}`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="screen no-tabs" onSubmit={onSubmit}>
      <div className="topbar">
        <button type="button" className="link" onClick={back}>
          Abbrechen
        </button>
        <span className="title" style={{ fontSize: 18 }}>
          {isNew ? 'Neues Rezept' : 'Bearbeiten'}
        </span>
        <button type="submit" className="link" disabled={saving} style={{ fontWeight: 800 }}>
          {saving ? '…' : 'Speichern'}
        </button>
      </div>

      <div className="field">
        <label>Name des Gerichts</label>
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="z. B. Kartoffelgratin" autoFocus={isNew && !title} />
      </div>

      <button type="button" className="imgbox" onClick={() => fileRef.current?.click()}>
        {imgUrl ? <img src={imgUrl} alt="" /> : <Icon name="image" size={32} />}
        <span>{imgUrl ? 'Foto ändern' : 'Foto hinzufügen'}</span>
      </button>
      <input ref={fileRef} type="file" accept="image/*" className="hidden-input" onChange={onImage} />

      <Section title="Mahlzeit (mehrere möglich)">
        <div className="chips">
          {MEAL_TYPES.map((m) => (
            <MealChip key={m} meal={m} on={meals.includes(m)} onClick={() => toggleMeal(m)} />
          ))}
        </div>
      </Section>

      <Section title="Dauer in Minuten">
        <div className="row">
          <div className="field">
            <label>Aktiv</label>
            <input className="input" inputMode="numeric" value={active} onChange={(e) => setActive(e.target.value)} placeholder="20" />
          </div>
          <div className="field">
            <label>Inaktiv (Ofen …)</label>
            <input className="input" inputMode="numeric" value={passive} onChange={(e) => setPassive(e.target.value)} placeholder="45" />
          </div>
          <div className="field">
            <label>Gesamt</label>
            <input className="input" inputMode="numeric" value={total} onChange={(e) => { setTotalTouched(true); setTotal(e.target.value); }} placeholder="65" />
          </div>
        </div>
        <div className="field">
          <label>Portionen</label>
          <input className="input" value={servings} onChange={(e) => setServings(e.target.value)} placeholder="z. B. 4 Personen" />
        </div>
      </Section>

      <Section title="Zutaten (eine pro Zeile)">
        <textarea className="input" style={{ minHeight: 160 }} value={ingText} onChange={(e) => setIngText(e.target.value)} placeholder={'1 kg Kartoffeln\n250 ml Sahne\nSalz, Pfeffer'} autoCorrect="off" />
      </Section>

      <Section title="Zubereitung (Schritte durch Leerzeile trennen)">
        <textarea className="input" style={{ minHeight: 220 }} value={stepsText} onChange={(e) => setStepsText(e.target.value)} placeholder={'Kartoffeln schälen und hobeln.\n\nSahne mit Gewürzen verrühren …'} />
      </Section>

      <Section
        title="Keywords"
        right={
          <button type="button" className="link" onClick={suggest}>
            <Icon name="sparkle" size={16} /> Vorschlagen
          </button>
        }
      >
        <div className="chips" style={{ marginBottom: 8 }}>
          {keywords.map((k) => (
            <KeywordChip key={k} label={k} onRemove={() => setKeywords(keywords.filter((x) => x !== k))} />
          ))}
          {keywords.length === 0 && <span className="muted">Noch keine Keywords.</span>}
        </div>
        <div className="row">
          <input
            className="input"
            value={newKw}
            onChange={(e) => setNewKw(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addKw();
              }
            }}
            placeholder="Keyword hinzufügen, z. B. Sommer"
            autoCapitalize="off"
            enterKeyHint="done"
          />
          <button type="button" className="btn secondary" style={{ flex: 'none', width: 56 }} onClick={addKw} aria-label="Hinzufügen">
            <Icon name="plus" size={20} />
          </button>
        </div>
      </Section>

      <Section title="Notizen">
        <textarea className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Varianten, Quelle (Buch, Seite), Tipps …" />
      </Section>

      <div style={{ marginTop: 16 }}>
        <Button type="submit" icon="check" disabled={saving}>
          {isNew ? 'Rezept speichern' : 'Änderungen speichern'}
        </Button>
      </div>
    </form>
  );
}
