import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import { useImageUrl, useRecipes } from '../lib/store';
import { collectKeywords, groupByLetter, searchRecipes } from '../lib/search';
import { MEAL_TYPES, type MealType } from '../lib/types';
import { exportAll, importAll } from '../lib/db';
import { useCookingMode } from '../lib/wakelock';
import { Button, Durations, Empty, Icon, KeywordChip, MealChip, RecipeCard, Section } from './components';

/* ---------- Inhaltsverzeichnis ---------- */
export function IndexScreen({ open }: { open: (id: string) => void }) {
  const { recipes, loading } = useRecipes();
  const [meal, setMeal] = useState<MealType | null>(null);
  const filtered = useMemo(() => (meal ? recipes.filter((r) => r.mealTypes.includes(meal)) : recipes), [recipes, meal]);
  const groups = useMemo(() => groupByLetter(filtered), [filtered]);

  return (
    <div className="screen">
      <div className="topbar">
        <span className="title">Rezepte</span>
      </div>
      <div className="chips scroll">
        <button type="button" className={`chip ${!meal ? 'dark' : ''}`} onClick={() => setMeal(null)}>
          Alle ({recipes.length})
        </button>
        {MEAL_TYPES.map((m) => (
          <MealChip key={m} meal={m} on={meal === m} onClick={() => setMeal(meal === m ? null : m)} />
        ))}
      </div>
      {!loading && recipes.length === 0 ? (
        <Empty icon="book" title="Noch keine Rezepte" text="Tippe unten auf „Scannen“, um dein erstes Rezept zu fotografieren." />
      ) : groups.length === 0 ? (
        <Empty icon="filter" title="Nichts in dieser Kategorie" />
      ) : (
        <>
          {groups.map((g) => (
            <div key={g.letter} id={`letter-${g.letter}`}>
              <div className="letter">{g.letter}</div>
              {g.recipes.map((r) => (
                <RecipeCard key={r.id} r={r} onClick={() => open(r.id)} />
              ))}
            </div>
          ))}
          {groups.length > 4 && (
            <div className="jumpbar">
              {groups.map((g) => (
                <button key={g.letter} type="button" onClick={() => document.getElementById(`letter-${g.letter}`)?.scrollIntoView({ block: 'start' })}>
                  {g.letter}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------- Suche ---------- */
export function SearchScreen({ open }: { open: (id: string) => void }) {
  const { recipes } = useRecipes();
  const [q, setQ] = useState('');
  const [meals, setMeals] = useState<MealType[]>([]);
  const [kw, setKw] = useState<string | null>(null);
  const keywords = useMemo(() => collectKeywords(recipes), [recipes]);
  const results = useMemo(() => searchRecipes(recipes, q, { mealTypes: meals, keyword: kw }), [recipes, q, meals, kw]);
  const toggle = (m: MealType) => setMeals((c) => (c.includes(m) ? c.filter((x) => x !== m) : [...c, m]));

  return (
    <div className="screen">
      <div className="topbar">
        <span className="title">Suche</span>
      </div>
      <div className="searchbox">
        <Icon name="search" />
        <input type="search" placeholder="z. B. Abendessen Käse, Blaubeeren …" value={q} onChange={(e) => setQ(e.target.value)} autoCorrect="off" autoCapitalize="off" enterKeyHint="search" />
        {q && (
          <button type="button" onClick={() => setQ('')} aria-label="Leeren">
            <Icon name="close" size={18} />
          </button>
        )}
      </div>
      <div className="chips scroll">
        {MEAL_TYPES.map((m) => (
          <MealChip key={m} meal={m} on={meals.includes(m)} onClick={() => toggle(m)} />
        ))}
      </div>
      {keywords.length > 0 && (
        <div className="chips scroll" style={{ marginTop: 6 }}>
          {keywords.map((k) => (
            <KeywordChip key={k.keyword} label={`${k.keyword} (${k.count})`} selected={kw === k.keyword} onClick={() => setKw(kw === k.keyword ? null : k.keyword)} />
          ))}
        </div>
      )}
      <div className="count">
        {results.length} {results.length === 1 ? 'Rezept' : 'Rezepte'}
      </div>
      {results.map((r) => (
        <RecipeCard key={r.id} r={r} onClick={() => open(r.id)} />
      ))}
      {results.length === 0 &&
        (recipes.length === 0 ? (
          <Empty icon="book" title="Noch keine Rezepte" text="Scanne zuerst ein Rezept." />
        ) : (
          <Empty icon="search" title="Nichts gefunden" text="Die Suche kennt Oberbegriffe wie „Käse“, „Beeren“, „Fisch“ oder „Nachtisch“. Mehrere Wörter müssen alle passen." />
        ))}
    </div>
  );
}

/* ---------- Mehr / Backup ---------- */
export function MoreScreen({ toast }: { toast: (s: string) => void }) {
  const { recipes, refresh } = useRecipes();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function doExport() {
    try {
      setBusy(true);
      const json = await exportAll();
      const name = `rezeptbuch-backup-${new Date().toISOString().slice(0, 10)}.json`;
      const file = new File([json], name, { type: 'application/json' });
      if (navigator.canShare?.({ files: [file] }) && navigator.share) {
        await navigator.share({ files: [file], title: 'Rezeptbuch-Backup' });
      } else {
        const url = URL.createObjectURL(file);
        const a = document.createElement('a');
        a.href = url;
        a.download = name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
      }
    } catch (e) {
      if ((e as Error)?.name !== 'AbortError') toast(`Export fehlgeschlagen: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  async function doImport(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    try {
      setBusy(true);
      const n = await importAll(await f.text());
      await refresh();
      toast(`${n} Rezepte importiert.`);
    } catch (err) {
      toast(`Import fehlgeschlagen: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  const standalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as unknown as { standalone?: boolean }).standalone === true;

  return (
    <div className="screen">
      <div className="topbar">
        <span className="title">Mehr</span>
      </div>
      <div className="box stat">
        <div className="n">{recipes.length}</div>
        <p className="help">{recipes.length === 1 ? 'Rezept' : 'Rezepte'} gespeichert, alles nur auf diesem Gerät.</p>
      </div>

      {!standalone && (
        <Section title="Als App installieren">
          <p className="help">
            <b>iPhone:</b> In Safari unten auf „Teilen“ tippen, dann „Zum Home-Bildschirm“. <b>Android:</b> Im Chrome-Menü (⋮) „App installieren“ bzw. „Zum Startbildschirm hinzufügen“. Danach läuft die App im Vollbild und auch offline.
          </p>
        </Section>
      )}

      <Section title="Backup & Übertragung">
        <p className="help">Exportiere alle Rezepte als Datei und schick sie dir selbst (AirDrop, Mail, Drive). Auf dem anderen Handy dann „Importieren“. Fotos sind nicht im Backup enthalten.</p>
        <div className="stack" style={{ marginTop: 12 }}>
          <Button icon="share" onClick={doExport} disabled={busy || recipes.length === 0}>
            Backup exportieren
          </Button>
          <Button icon="download" variant="secondary" onClick={() => fileRef.current?.click()} disabled={busy}>
            Backup importieren
          </Button>
          <input ref={fileRef} type="file" accept=".json,application/json,text/plain" className="hidden-input" onChange={doImport} />
        </div>
      </Section>

      <Section title="So funktioniert die Erkennung">
        <p className="help">Der Text wird mit Tesseract direkt im Browser gelesen, ohne Internet, nichts verlässt dein Handy. Gedruckter Text klappt gut, Handschrift nur bei sauberer Druckschrift. Danach zerlegt die App den Text mit Regeln in Titel, Zutaten, Schritte und Zeiten und schlägt Mahlzeit-Typen und Keywords vor. Prüfe den Vorschlag kurz im Editor.</p>
      </Section>

      <Section title="Such-Tipps">
        <p className="help">„Käse“ findet Mozzarella, Gouda, Feta …, „Beeren“ findet Blaubeeren und Himbeeren, „Nachtisch“ alles vom Typ Nachspeise. Mehrere Wörter werden UND-verknüpft: „Abendessen Käse“ zeigt nur Abendessen mit Käse.</p>
      </Section>
    </div>
  );
}

/* ---------- Rezeptansicht ---------- */
export function DetailScreen({ id, back, edit }: { id: string; back: () => void; edit: () => void }) {
  const { byId, remove, loading } = useRecipes();
  const r = byId(id);
  const img = useImageUrl(r?.imageUri ?? null);
  const [showSrc, setShowSrc] = useState(false);
  const [done, setDone] = useState<Set<number>>(new Set());
  const cook = useCookingMode();
  useEffect(() => window.scrollTo(0, 0), [id]);

  if (!r) {
    return (
      <div className="screen no-tabs">
        <div className="topbar">
          <button type="button" className="link" onClick={back}>
            <Icon name="back" size={20} /> Zurück
          </button>
        </div>
        {!loading && <Empty icon="alert" title="Rezept nicht gefunden" />}
      </div>
    );
  }

  const toggle = (i: number) =>
    setDone((c) => {
      const n = new Set(c);
      n.has(i) ? n.delete(i) : n.add(i);
      return n;
    });

  async function del() {
    if (!confirm(`„${r!.title}“ endgültig löschen?`)) return;
    await remove(r!.id);
    back();
  }

  return (
    <div className="screen no-tabs">
      <div className="topbar">
        <button type="button" className="link" onClick={back}>
          <Icon name="back" size={20} /> Zurück
        </button>
        <button type="button" className="link" onClick={edit}>
          <Icon name="edit" size={20} /> Bearbeiten
        </button>
      </div>
      <h1>{r.title}</h1>
      {r.mealTypes.length > 0 && (
        <div className="chips" style={{ marginTop: 8 }}>
          {r.mealTypes.map((m) => (
            <MealChip key={m} meal={m} />
          ))}
        </div>
      )}
      <div className="box" style={{ marginTop: 16 }}>
        <Durations r={r} />
        {r.servings && (
          <div className="durations" style={{ marginTop: 8 }}>
            <span className="item">
              <Icon name="people" size={16} />
              <b>{r.servings}</b>
            </span>
          </div>
        )}
      </div>
      <button type="button" className={`cookmode ${cook.active ? 'on' : ''}`} onClick={cook.toggle} aria-pressed={cook.active}>
        <Icon name="flame" size={22} filled={cook.active} />
        <span className="cook-text">
          <b>{cook.active ? 'Am Kochen: Bildschirm bleibt an' : 'Am Kochen'}</b>
          <small>{cook.active ? 'Tippen zum Beenden' : cook.supported ? 'Bildschirm sperrt sich nicht, solange du kochst' : 'Auf diesem Gerät nicht unterstützt (Safari ab iOS 16.4 oder Chrome)'}</small>
        </span>
        <span className={`switch ${cook.active ? 'on' : ''}`} />
      </button>
      {cook.error && <p className="help" style={{ marginTop: 6 }}>Konnte den Bildschirm nicht wach halten: {cook.error}. Bei niedrigem Akku blockiert das Handy das manchmal.</p>}

      {img && <img className="hero-img" src={img} alt="" />}

      <Section title={`Zutaten (${r.ingredients.length})`}>
        <div className="box">
          {r.ingredients.length === 0 && <span className="muted">Keine Zutaten erfasst.</span>}
          {r.ingredients.map((ing, i) => (
            <button type="button" key={i} className={`ing ${done.has(i) ? 'done' : ''}`} onClick={() => toggle(i)}>
              <Icon name={done.has(i) ? 'checkbox' : 'square'} size={20} />
              <span className="amt">{ing.amount}</span>
              <span className="name">{ing.name}</span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Zubereitung">
        {r.steps.length === 0 && <span className="muted">Keine Schritte erfasst.</span>}
        {r.steps.map((s, i) => (
          <div className="step" key={i}>
            <span className="num">{i + 1}</span>
            <p>{s}</p>
          </div>
        ))}
      </Section>

      {r.keywords.length > 0 && (
        <Section title="Keywords">
          <div className="chips">
            {r.keywords.map((k) => (
              <KeywordChip key={k} label={k} />
            ))}
          </div>
        </Section>
      )}
      {r.notes.trim() && (
        <Section title="Notizen">
          <p style={{ margin: 0, lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{r.notes}</p>
        </Section>
      )}
      {r.sourceText.trim() && (
        <Section
          title="Originaltext (OCR)"
          right={
            <button type="button" className="link" onClick={() => setShowSrc((v) => !v)}>
              {showSrc ? 'Ausblenden' : 'Anzeigen'}
            </button>
          }
        >
          {showSrc && (
            <div className="box">
              <pre className="ocr muted">{r.sourceText}</pre>
            </div>
          )}
        </Section>
      )}
      <div style={{ marginTop: 24 }}>
        <Button variant="ghost" icon="trash" onClick={del}>
          Rezept löschen
        </Button>
      </div>
    </div>
  );
}
