import { useCallback, useEffect, useState } from 'react';
import { RecipesProvider, useRoute } from './lib/store';
import { Icon } from './ui/components';
import { DetailScreen, IndexScreen, MoreScreen, SearchScreen } from './ui/screens';
import { ScanScreen } from './ui/scan';
import { EditScreen } from './ui/edit';

const TABS = [
  { key: '', label: 'Rezepte', icon: 'book' },
  { key: 'search', label: 'Suche', icon: 'search' },
  { key: 'scan', label: 'Scannen', icon: 'camera' },
  { key: 'more', label: 'Mehr', icon: 'more' },
];

export default function App() {
  return (
    <RecipesProvider>
      <Shell />
    </RecipesProvider>
  );
}

function Shell() {
  const { path, navigate, back } = useRoute();
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toast = useCallback((s: string) => setToastMsg(s), []);
  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 3500);
    return () => clearTimeout(t);
  }, [toastMsg]);

  const [head, arg] = path;
  const open = (id: string) => navigate(`recipe/${id}`);
  let screen;
  let showTabs = true;
  if (head === 'recipe' && arg) {
    screen = <DetailScreen id={arg} back={back} edit={() => navigate(`edit/${arg}`)} />;
    showTabs = false;
  } else if (head === 'edit' && arg) {
    screen = <EditScreen id={arg} back={back} toast={toast} done={(id) => navigate(`recipe/${id}`, true)} />;
    showTabs = false;
  } else if (head === 'search') screen = <SearchScreen open={open} />;
  else if (head === 'scan') screen = <ScanScreen toEditor={() => navigate('edit/new')} toast={toast} />;
  else if (head === 'more') screen = <MoreScreen toast={toast} />;
  else screen = <IndexScreen open={open} />;

  return (
    <div className="app">
      {screen}
      {showTabs && (
        <nav className="tabbar">
          {TABS.map((t) => (
            <button key={t.key} type="button" className={(head ?? '') === t.key || (!head && t.key === '') ? 'active' : ''} onClick={() => navigate(t.key)}>
              <Icon name={t.icon} size={24} />
              {t.label}
            </button>
          ))}
        </nav>
      )}
      {toastMsg && <div className="toast">{toastMsg}</div>}
    </div>
  );
}
