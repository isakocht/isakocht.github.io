import { createWorker, PSM, type Worker } from 'tesseract.js';

/**
 * Texterkennung im Browser mit Tesseract (läuft komplett auf dem Gerät).
 * Worker, WASM und Sprachdaten (deu + eng) liegen unter /tess und werden vom Service Worker
 * mitgecacht, damit die Erkennung auch offline funktioniert.
 */

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');
let workerPromise: Promise<Worker> | null = null;

export type ProgressFn = (status: string, progress: number) => void;

function getWorker(onProgress?: ProgressFn): Promise<Worker> {
  if (!workerPromise) {
    workerPromise = createWorker(['deu', 'eng'], 1, {
      workerPath: `${BASE}/tess/worker.min.js`,
      corePath: `${BASE}/tess`,
      langPath: `${BASE}/tess`,
      gzip: true,
      logger: (m) => onProgress?.(m.status, m.progress),
    }).catch((e) => {
      workerPromise = null;
      throw e;
    });
  }
  return workerPromise;
}

/** Lädt die Erkennung im Hintergrund vor, damit der erste Scan schneller geht. */
export function warmUp() {
  getWorker().catch(() => {});
}

/**
 * Bild fürs OCR aufbereiten: auf max. 2000 px skalieren, Graustufen, Kontrast anheben.
 * Gibt außerdem eine kleinere JPEG-Version zum Speichern zurück.
 */
export async function prepareImage(file: Blob): Promise<{ ocrCanvas: HTMLCanvasElement; thumbnail: Blob }> {
  const bitmap = await loadBitmap(file);
  const maxOcr = 2000;
  const scale = Math.min(1, maxOcr / Math.max(bitmap.width, bitmap.height));
  const w = Math.round(bitmap.width * scale);
  const h = Math.round(bitmap.height * scale);

  const ocrCanvas = document.createElement('canvas');
  ocrCanvas.width = w;
  ocrCanvas.height = h;
  const ctx = ocrCanvas.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(bitmap, 0, 0, w, h);

  // Graustufen + leichte Kontrastanhebung, hilft Tesseract bei Fotos von Buchseiten
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  let min = 255;
  let max = 0;
  for (let i = 0; i < d.length; i += 4) {
    const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    d[i] = d[i + 1] = d[i + 2] = g;
    if (g < min) min = g;
    if (g > max) max = g;
  }
  const range = Math.max(1, max - min);
  for (let i = 0; i < d.length; i += 4) {
    const v = ((d[i] - min) / range) * 255;
    d[i] = d[i + 1] = d[i + 2] = v;
  }
  ctx.putImageData(img, 0, 0);

  // Farb-Thumbnail zum Speichern (max. 1400 px, JPEG)
  const maxThumb = 1400;
  const ts = Math.min(1, maxThumb / Math.max(bitmap.width, bitmap.height));
  const tc = document.createElement('canvas');
  tc.width = Math.round(bitmap.width * ts);
  tc.height = Math.round(bitmap.height * ts);
  tc.getContext('2d')!.drawImage(bitmap, 0, 0, tc.width, tc.height);
  const thumbnail = await new Promise<Blob>((res, rej) => tc.toBlob((b) => (b ? res(b) : rej(new Error('Bild konnte nicht gespeichert werden'))), 'image/jpeg', 0.85));
  if ('close' in bitmap) (bitmap as ImageBitmap).close();
  return { ocrCanvas, thumbnail };
}

async function loadBitmap(file: Blob): Promise<ImageBitmap | HTMLImageElement> {
  if ('createImageBitmap' in window) {
    try {
      return await createImageBitmap(file, { imageOrientation: 'from-image' } as ImageBitmapOptions);
    } catch {
      /* Fallback unten */
    }
  }
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => {
      URL.revokeObjectURL(url);
      res(im);
    };
    im.onerror = () => rej(new Error('Bild konnte nicht geladen werden'));
    im.src = url;
  });
}

/**
 * Text erkennen. Blöcke werden nach Spalten sortiert, damit zweispaltige Layouts
 * (Zutaten links, Zubereitung rechts) sinnvoll gelesen werden.
 */
export async function recognizeText(canvas: HTMLCanvasElement, onProgress?: ProgressFn): Promise<string> {
  const worker = await getWorker(onProgress);
  await worker.setParameters({ tessedit_pageseg_mode: PSM.AUTO, preserve_interword_spaces: '1' });
  const { data } = await worker.recognize(canvas, {}, { blocks: true, text: true });
  const blocks = (data.blocks ?? []).filter((b) => b.text.trim().length > 0);
  if (blocks.length < 3) return data.text;

  const maxRight = Math.max(...blocks.map((b) => b.bbox.x1));
  const mid = maxRight / 2;
  const left = blocks.filter((b) => (b.bbox.x0 + b.bbox.x1) / 2 < mid);
  const right = blocks.filter((b) => !left.includes(b));
  const overlaps = (a: typeof blocks[number], b: typeof blocks[number]) => a.bbox.y0 < b.bbox.y1 && b.bbox.y0 < a.bbox.y1;
  const twoColumn = left.length >= 2 && right.length >= 2 && left.some((l) => right.some((r) => overlaps(l, r)));
  const byTop = (a: typeof blocks[number], b: typeof blocks[number]) => a.bbox.y0 - b.bbox.y0;
  const ordered = twoColumn ? [...left.sort(byTop), ...right.sort(byTop)] : [...blocks].sort(byTop);
  return ordered.map((b) => b.paragraphs.map((p) => p.lines.map((l) => l.text.trimEnd()).join('\n')).join('\n')).join('\n');
}
