import { expandTerm, normalize, stemEquals } from './knowledge';
import { MEAL_TYPES, type MealType, type Recipe } from './types';

export interface SearchOptions {
  mealTypes?: MealType[];
  keyword?: string | null;
}

/**
 * Sucht Rezepte. Jeder Suchbegriff muss irgendwo treffen (UND-Verknüpfung),
 * Begriffe werden über Synonyme/Oberbegriffe erweitert ("käse" findet Mozzarella).
 * Ergebnis ist nach Relevanz sortiert.
 */
export function searchRecipes(recipes: Recipe[], query: string, opts: SearchOptions = {}): Recipe[] {
  const terms = normalize(query).split(' ').filter((t) => t.length > 1);
  const scored: { r: Recipe; score: number }[] = [];

  for (const r of recipes) {
    if (opts.mealTypes && opts.mealTypes.length > 0 && !opts.mealTypes.some((m) => r.mealTypes.includes(m))) continue;
    if (opts.keyword && !r.keywords.some((k) => normalize(k) === normalize(opts.keyword!))) continue;

    const idx = buildIndex(r);
    let total = 0;
    let ok = true;
    for (const term of terms) {
      const s = scoreTerm(idx, term);
      if (s === 0) {
        ok = false;
        break;
      }
      total += s;
    }
    if (ok) scored.push({ r, score: total });
  }

  scored.sort((a, b) => b.score - a.score || a.r.title.localeCompare(b.r.title, 'de'));
  return scored.map((s) => s.r);
}

interface Index {
  title: string[];
  ingredients: string[];
  keywords: string[];
  meals: string[];
  steps: string[];
}

function words(s: string): string[] {
  return normalize(s).split(' ').filter(Boolean);
}

export function buildIndex(r: Recipe): Index {
  return {
    title: words(r.title),
    ingredients: r.ingredients.flatMap((i) => words(i.name)),
    keywords: r.keywords.flatMap(words),
    meals: r.mealTypes.flatMap((m) => [...words(m), ...expandTerm(m)]),
    steps: r.steps.flatMap(words),
  };
}

function hit(list: string[], variants: string[]): boolean {
  for (const w of list) {
    for (const v of variants) {
      if (w === v || stemEquals(w, v)) return true;
      // Teilwort: "kaese" in "kaesekuchen", "beere" in "blaubeeren"
      if (v.length >= 4 && w.includes(v)) return true;
    }
  }
  return false;
}

function scoreTerm(idx: Index, term: string): number {
  const variants = expandTerm(term);
  let s = 0;
  if (hit(idx.title, variants)) s += 10;
  if (hit(idx.meals, variants)) s += 8;
  if (hit(idx.keywords, variants)) s += 6;
  if (hit(idx.ingredients, variants)) s += 5;
  if (s === 0 && hit(idx.steps, variants)) s += 1;
  return s;
}

/** Erkennt, ob ein Suchbegriff ein Mahlzeit-Typ ist (z. B. "abendessen", "dessert"). */
export function mealTypeFromTerm(term: string): MealType | null {
  const variants = expandTerm(term);
  for (const m of MEAL_TYPES) {
    const mv = expandTerm(m);
    if (variants.some((v) => mv.includes(v))) return m;
  }
  return null;
}

/** Alle Keywords über alle Rezepte, mit Häufigkeit, alphabetisch. */
export function collectKeywords(recipes: Recipe[]): { keyword: string; count: number }[] {
  const map = new Map<string, number>();
  for (const r of recipes) for (const k of r.keywords) map.set(k, (map.get(k) ?? 0) + 1);
  return [...map.entries()]
    .map(([keyword, count]) => ({ keyword, count }))
    .sort((a, b) => a.keyword.localeCompare(b.keyword, 'de'));
}

/** Inhaltsverzeichnis: Rezepte gruppiert nach Anfangsbuchstabe. */
export function groupByLetter(recipes: Recipe[]): { letter: string; recipes: Recipe[] }[] {
  const map = new Map<string, Recipe[]>();
  const sorted = [...recipes].sort((a, b) => a.title.localeCompare(b.title, 'de'));
  for (const r of sorted) {
    const first = (r.title.trim()[0] ?? '#').toUpperCase();
    const letter = /[A-ZÄÖÜ]/.test(first) ? first.replace('Ä', 'A').replace('Ö', 'O').replace('Ü', 'U') : '#';
    if (!map.has(letter)) map.set(letter, []);
    map.get(letter)!.push(r);
  }
  return [...map.entries()].map(([letter, recipes]) => ({ letter, recipes }));
}
