import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Kochmodus: hält den Bildschirm an (Screen Wake Lock API).
 * Das System gibt den Lock frei, wenn die App in den Hintergrund geht; beim Zurückkommen
 * holen wir ihn automatisch wieder, solange der Modus eingeschaltet ist.
 */
type WakeLockSentinel = { release: () => Promise<void>; addEventListener: (t: 'release', f: () => void) => void };
type WakeNavigator = Navigator & { wakeLock?: { request: (type: 'screen') => Promise<WakeLockSentinel> } };

export const wakeLockSupported = typeof navigator !== 'undefined' && 'wakeLock' in navigator;

export function useCookingMode(): { active: boolean; supported: boolean; toggle: () => void; error: string | null } {
  const [active, setActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sentinel = useRef<WakeLockSentinel | null>(null);

  const acquire = useCallback(async () => {
    const nav = navigator as WakeNavigator;
    if (!nav.wakeLock) return;
    try {
      const s = await nav.wakeLock.request('screen');
      sentinel.current = s;
      s.addEventListener('release', () => {
        if (sentinel.current === s) sentinel.current = null;
      });
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);

  const release = useCallback(async () => {
    const s = sentinel.current;
    sentinel.current = null;
    if (s) await s.release().catch(() => {});
  }, []);

  useEffect(() => {
    if (!active) {
      release();
      return;
    }
    acquire();
    const onVis = () => {
      if (document.visibilityState === 'visible' && !sentinel.current) acquire();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      release();
    };
  }, [active, acquire, release]);

  return { active, supported: wakeLockSupported, toggle: () => setActive((v) => !v), error };
}
