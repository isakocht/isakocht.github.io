export const MEAL_TYPES = [
  'Frühstück',
  'Vorspeise',
  'Mittag',
  'Abendessen',
  'Side-dish',
  'Nachspeise',
] as const;

export type MealType = (typeof MEAL_TYPES)[number];

export interface Ingredient {
  /** Menge inkl. Einheit, z. B. "200 g" oder "2 EL" (kann leer sein) */
  amount: string;
  /** Zutat, z. B. "Mehl" */
  name: string;
}

export interface Recipe {
  id: string;
  title: string;
  ingredients: Ingredient[];
  steps: string[];
  /** Minuten, in denen ich aktiv arbeite */
  activeMinutes: number | null;
  /** Minuten Wartezeit (Ofen, Garen, Kühlen …) */
  passiveMinutes: number | null;
  /** Gesamtdauer in Minuten (aktiv + passiv, oder explizit angegeben) */
  totalMinutes: number | null;
  servings: string | null;
  mealTypes: MealType[];
  keywords: string[];
  /** Roher OCR-Text, damit nichts verloren geht */
  sourceText: string;
  /** Lokaler Pfad zum Originalfoto */
  imageUri: string | null;
  notes: string;
  createdAt: number;
  updatedAt: number;
}

export type RecipeDraft = Omit<Recipe, 'id' | 'createdAt' | 'updatedAt'>;

export function emptyDraft(): RecipeDraft {
  return {
    title: '',
    ingredients: [],
    steps: [],
    activeMinutes: null,
    passiveMinutes: null,
    totalMinutes: null,
    servings: null,
    mealTypes: [],
    keywords: [],
    sourceText: '',
    imageUri: null,
    notes: '',
  };
}

export function computeTotal(active: number | null, passive: number | null, explicit: number | null): number | null {
  if (explicit != null) return explicit;
  if (active == null && passive == null) return null;
  return (active ?? 0) + (passive ?? 0);
}
