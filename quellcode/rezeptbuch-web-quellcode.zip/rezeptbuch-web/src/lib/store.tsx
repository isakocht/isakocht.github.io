import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import * as db from './db';
import type { Recipe, RecipeDraft } from './types';

interface Store {
  recipes: Recipe[];
  loading: boolean;
  refresh: () => Promise<void>;
  create: (draft: RecipeDraft) => Promise<Recipe>;
  update: (id: string, draft: RecipeDraft) => Promise<void>;
  remove: (id: string) => Promise<void>;
  byId: (id: string) => Recipe | undefined;
}

const Ctx = createContext<Store | null>(null);

export function RecipesProvider({ children }: { children: ReactNode }) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setRecipes(await db.listRecipes());
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh().catch((e) => {
      console.error('Datenbank konnte nicht geladen werden', e);
      setLoading(false);
    });
    db.requestPersistentStorage();
  }, [refresh]);

  const value = useMemo<Store>(
    () => ({
      recipes,
      loading,
      refresh,
      create: async (d) => {
        const r = await db.insertRecipe(d);
        await refresh();
        return r;
      },
      update: async (id, d) => {
        await db.updateRecipe(id, d);
        await refresh();
      },
      remove: async (id) => {
        await db.deleteRecipe(id);
        await refresh();
      },
      byId: (id) => recipes.find((r) => r.id === id),
    }),
    [recipes, loading, refresh],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useRecipes(): Store {
  const s = useContext(Ctx);
  if (!s) throw new Error('useRecipes außerhalb von RecipesProvider');
  return s;
}

/** Übergabe eines frisch gescannten Entwurfs an den Editor. */
let pendingDraft: RecipeDraft | null = null;
export const setPendingDraft = (d: RecipeDraft | null) => {
  pendingDraft = d;
};
export const takePendingDraft = () => {
  const d = pendingDraft;
  pendingDraft = null;
  return d;
};

/** Objekt-URL für ein gespeichertes Bild, wird beim Unmount wieder freigegeben. */
export function useImageUrl(ref: string | null): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    let created: string | null = null;
    setUrl(null);
    if (ref) {
      db.loadImage(ref).then((blob) => {
        if (!active || !blob) return;
        created = URL.createObjectURL(blob);
        setUrl(created);
      });
    }
    return () => {
      active = false;
      if (created) URL.revokeObjectURL(created);
    };
  }, [ref]);
  return url;
}

/** Minimaler Hash-Router: #/, #/search, #/scan, #/more, #/recipe/ID, #/edit/ID */
export function useRoute(): { path: string[]; navigate: (to: string, replace?: boolean) => void; back: () => void } {
  const parse = () => window.location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  const [path, setPath] = useState<string[]>(parse);
  useEffect(() => {
    const on = () => setPath(parse());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  const navigate = useCallback((to: string, replace = false) => {
    const hash = `#/${to.replace(/^\/+/, '')}`;
    if (replace) window.location.replace(hash);
    else window.location.hash = hash;
  }, []);
  const back = useCallback(() => {
    if (window.history.length > 1) window.history.back();
    else navigate('', true);
  }, [navigate]);
  return { path, navigate, back };
}
