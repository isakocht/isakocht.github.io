import { INGREDIENT_GROUPS, KEYWORD_RULES, MEAL_RULES, NON_VEGAN, NON_VEGETARIAN, normalize } from './knowledge';
import { computeTotal, emptyDraft, type Ingredient, type MealType, type RecipeDraft } from './types';

/**
 * Heuristischer Parser: macht aus rohem OCR-Text einen Rezept-Entwurf.
 * Alles ist danach im Editor korrigierbar, der Parser muss also nur "gut genug" sein.
 */

const UNITS =
  'g|gr|gramm|kg|ml|l|liter|el|tl|msp|prise|prisen|stück|stk|st|scheibe|scheiben|bund|zehe|zehen|dose|dosen|packung|päckchen|pck|pkg|becher|tasse|tassen|glas|gläser|handvoll|zweig|zweige|blatt|blätter|würfel|tropfen|spritzer|schuss|cup|cups|tbsp|tsp|oz|lb|pound|ounce|dl|cl|stange|stangen|kugel|kugeln|riegel|tüte|beutel|bl|rolle';
const UNIT_RE = new RegExp(`^(${UNITS})\\b\\.?`, 'i');
const FRACTIONS: Record<string, string> = { '½': '1/2', '¼': '1/4', '¾': '3/4', '⅓': '1/3', '⅔': '2/3', '⅛': '1/8' };

const QTY_START = /^(ca\.?\s*|etwa\s*|ungefähr\s*)?(\d+\s*\/\s*\d+|\d+([.,]\d+)?(\s*[-–bis]+\s*\d+([.,]\d+)?)?|[½¼¾⅓⅔⅛]|etwas|einige|wenig|eine?\s+prise|eine?\s+handvoll|nach\s+belieben|nach\s+geschmack|einige?|ein|eine|einen|zwei|drei|vier|fünf|sechs|acht|zehn)\b/i;

const INGREDIENT_HEADER = /^(zutaten|ingredients|einkaufsliste|für den teig|für die füllung|für die sauce|für die soße|für das dressing|für den belag|für die creme|für den boden|außerdem|zusätzlich|teig|füllung|belag|topping|dressing|sauce|soße|marinade)\b[:\s]*$/i;
const STEP_HEADER = /^(zubereitung|anleitung|so geht'?s|so wird'?s gemacht|schritte|zubereitungsschritte|instructions|method|directions|preparation|und so geht'?s)\b[:\s]*$/i;
const NOISE_LINE = /^(seite\s*\d+|\d{1,3}|www\..*|https?:.*|[•·\-–_=*]+|tipp:?|notizen?:?|foto:.*|bild:.*)$/i;

interface TimeMatch {
  minutes: number;
  kind: 'active' | 'passive' | 'total';
}

const TIME_LABELS: { re: RegExp; kind: TimeMatch['kind'] }[] = [
  { re: /\b(gesamt(zeit|dauer)?|insgesamt|total(\s*time)?|dauer|fertig in)\b\s*[:\-]?\s*/i, kind: 'total' },
  { re: /\b(arbeitszeit|zubereitungszeit|zubereitung|vorbereitung(szeit)?|aktiv(e zeit)?|prep(\s*time)?|hands[- ]on|active)\b\s*[:\-]?\s*/i, kind: 'active' },
  { re: /\b(back(zeit|dauer)|koch(zeit|dauer)|gar(zeit|dauer)|ruhe(zeit)?|kühl(zeit)?|warte(zeit)?|geh(zeit)?|brat(zeit)?|schmor(zeit)?|marinier(zeit)?|einweich(zeit)?|cook(ing)?(\s*time)?|bake\s*time|rest(ing)?\s*time|chill(ing)?\s*time|inaktiv|passiv)\b\s*[:\-]?\s*/i, kind: 'passive' },
];

const PASSIVE_VERBS = /(backen|garen|köcheln|kochen lassen|ziehen lassen|ruhen|gehen lassen|kühlen|kühl stellen|kalt stellen|marinieren|einweichen|schmoren|simmern|quellen|abkühlen|in den ofen|im ofen|bei \d{2,3}\s*°|\d{2,3}\s*grad|über nacht|einfrieren|gefrieren|trocknen|reifen)/i;

/** Sucht "1 Std 30 Min", "45 Minuten", "1,5 Stunden", "2 h", "90 min" in einem String und gibt Minuten zurück. */
export function parseDurationMinutes(text: string): number | null {
  const t = text.toLowerCase().replace(',', '.');
  let minutes = 0;
  let found = false;
  const range = t.match(/(\d+(?:\.\d+)?)\s*(?:-|–|bis)\s*(\d+(?:\.\d+)?)\s*(min|minuten|std|stunden|h)/);
  if (range) {
    // Bei Spannen den größeren Wert nehmen
    const v = parseFloat(range[2]);
    return /min/.test(range[3]) ? Math.round(v) : Math.round(v * 60);
  }
  const hours = t.match(/(\d+(?:\.\d+)?)\s*(std\.?|stunden?|hours?|hrs?|h)\b/);
  if (hours) {
    minutes += parseFloat(hours[1]) * 60;
    found = true;
  }
  const mins = t.match(/(\d+)\s*(min\.?|minuten?|minutes?|mins?)\b/);
  if (mins) {
    minutes += parseInt(mins[1], 10);
    found = true;
  }
  if (!found) {
    const overnight = /über nacht|overnight/.test(t);
    if (overnight) return 8 * 60;
    return null;
  }
  return Math.round(minutes);
}

function cleanLines(raw: string): string[] {
  let text = raw.replace(/\r/g, '\n');
  for (const [k, v] of Object.entries(FRACTIONS)) text = text.split(k).join(v + ' ');
  // Silbentrennung am Zeilenende zusammenziehen: "Kartof-\nfeln" → "Kartoffeln"
  text = text.replace(/([a-zäöüß])-\n([a-zäöüß])/g, '$1$2');
  return text
    .split('\n')
    .map((l) => l.replace(/\s+/g, ' ').replace(/^[•·▪■●○\-–*]\s*/, '').trim())
    .filter((l) => l.length > 0 && !NOISE_LINE.test(l));
}

/** Zerlegt eine Zutatenzeile in Menge und Name. */
export function parseIngredientLine(line: string): Ingredient {
  let rest = line.trim().replace(/^[-–•*]\s*/, '');
  for (const [k, v] of Object.entries(FRACTIONS)) rest = rest.split(k).join(v + ' ').replace(/\s+/g, ' ');
  const qty = rest.match(QTY_START);
  let amount = '';
  if (qty) {
    amount = qty[0].trim();
    rest = rest.slice(qty[0].length).trim();
    const unit = rest.match(UNIT_RE);
    if (unit) {
      amount = `${amount} ${unit[0].replace(/\.$/, '')}`.trim();
      rest = rest.slice(unit[0].length).trim();
    }
  } else {
    // Menge hinter der Zutat, z. B. "Mehl 200 g" oder "Salz, Pfeffer"
    const trailing = rest.match(/\s(\d+([.,]\d+)?\s*(?:[a-zäöü]{1,8})?)$/i);
    if (trailing) {
      amount = trailing[1].trim();
      rest = rest.slice(0, trailing.index).trim();
    }
  }
  rest = rest.replace(/^(von|an|frische[rn]?|frisch|gehackte[rn]?|gerieben(e[rn]?)?|geschält(e[rn]?)?|gewürfelt(e[rn]?)?)\s+/i, '');
  rest = rest.replace(/[.;:]+$/, '').trim();
  return { amount, name: rest };
}

function looksLikeIngredient(line: string): boolean {
  if (line.length > 70) return false;
  if (QTY_START.test(line)) return true;
  const w = line.split(' ');
  if (w.length <= 5 && new RegExp(`\\b(${UNITS})\\b`, 'i').test(line)) return true;
  if (w.length <= 3 && /^[A-ZÄÖÜ]/.test(line) && !/[.!?]$/.test(line)) return true; // "Salz, Pfeffer"
  return false;
}

function looksLikeStep(line: string): boolean {
  if (/^\d{1,2}[.)]\s+\S/.test(line)) return true;
  const w = line.split(' ');
  return w.length >= 7 || /[.!]$/.test(line);
}

function looksLikeTitle(line: string): boolean {
  const w = line.split(' ');
  if (w.length > 8 || line.length < 3) return false;
  if (QTY_START.test(line) && !/^\d+\s*(er|-)?\s*[a-zäöü]/i.test(line)) return false;
  if (INGREDIENT_HEADER.test(line) || STEP_HEADER.test(line)) return false;
  if (TIME_LABELS.some((t) => t.re.test(line)) && parseDurationMinutes(line) != null) return false;
  if (/personen|portionen|servings|serves|ergibt/i.test(line)) return false;
  if (/[.!?]$/.test(line) && w.length > 4) return false;
  return true;
}

export function parseServings(text: string): string | null {
  const m =
    text.match(/(?:für|for|ergibt|reicht für|serves|yields?)\s*(?:ca\.?\s*)?(\d+(?:\s*[-–]\s*\d+)?)\s*(personen|portionen|stück|servings|people|muffins|scheiben|gläser|stk|st\.?)?/i) ||
    text.match(/(\d+(?:\s*[-–]\s*\d+)?)\s*(personen|portionen|servings|portions?)\b/i);
  if (!m) return null;
  const unit = m[2] ? m[2].replace(/\.$/, '') : 'Portionen';
  return `${m[1].replace(/\s/g, '')} ${unit.charAt(0).toUpperCase() + unit.slice(1).toLowerCase()}`;
}

/** Findet beschriftete Zeiten im Text. */
export function extractLabeledTimes(text: string): TimeMatch[] {
  const out: TimeMatch[] = [];
  const lines = text.split('\n');
  for (const line of lines) {
    // Eine Zeile kann mehrere Angaben tragen: "Zubereitung: 20 Min | Backzeit: 40 Min"
    const parts = line.split(/[|;•·]|\s{2,}|(?<=min\.?|minuten|std\.?|stunden|h)\s+(?=[A-ZÄÖÜ])/i);
    for (const part of parts) {
      const found: { idx: number; len: number; kind: TimeMatch['kind'] }[] = [];
      for (const { re, kind } of TIME_LABELS) {
        const m = part.match(re);
        if (m) found.push({ idx: m.index!, len: m[0].length, kind });
      }
      found.sort((a, b) => a.idx - b.idx);
      for (let i = 0; i < found.length; i++) {
        const f = found[i];
        const next = found[i + 1]?.idx ?? part.length;
        const after = part.slice(f.idx + f.len, next);
        const mins = parseDurationMinutes(after);
        if (mins != null) out.push({ minutes: mins, kind: f.kind });
      }
    }
  }
  return out;
}

/** Summe passiver Zeiten aus den Schritten ("40 Minuten backen", "1 Stunde ruhen lassen"). */
export function passiveMinutesFromSteps(steps: string[]): number {
  let sum = 0;
  for (const step of steps) {
    const sentences = step.split(/(?<=[.!])\s+/);
    for (const s of sentences) {
      if (!PASSIVE_VERBS.test(s)) continue;
      const mins = parseDurationMinutes(s);
      if (mins != null && mins <= 24 * 60) sum += mins;
    }
  }
  return sum;
}

export function inferMealTypes(title: string, keywords: string[], ingredients: Ingredient[], steps: string[]): MealType[] {
  const hay = `${title} ${keywords.join(' ')}`;
  const set = new Set<MealType>();
  for (const rule of MEAL_RULES) if (rule.pattern.test(hay)) rule.meals.forEach((m) => set.add(m));
  if (set.size === 0) {
    // Fallback über Zutaten: süß → Nachspeise, sonst Hauptgericht
    const names = ingredients.map((i) => normalize(i.name)).join(' ');
    const sweet = /zucker|puderzucker|vanille|schokolade|kakao|honig|ahornsirup|sahne|mehl/.test(names);
    const savory = /salz|pfeffer|zwiebel|knoblauch|oel|brühe|bruehe|fleisch|kaese|tomat/.test(names);
    if (sweet && !savory) set.add('Nachspeise');
    else if (ingredients.length > 0 || steps.length > 0) {
      set.add('Mittag');
      set.add('Abendessen');
    } else set.add('Sonstiges');
  }
  return [...set];
}

export function inferKeywords(title: string, ingredients: Ingredient[], steps: string[], _mealTypes: MealType[]): string[] {
  const set = new Set<string>();
  const fullText = `${title}\n${ingredients.map((i) => i.name).join('\n')}\n${steps.join('\n')}`;
  const names = ingredients.map((i) => normalize(i.name));

  for (const rule of MEAL_RULES) if (rule.keyword && rule.pattern.test(title)) set.add(rule.keyword);
  for (const rule of KEYWORD_RULES) if (rule.pattern.test(fullText)) set.add(rule.keyword);

  // Hauptzutaten-Gruppen als Keywords (Käse, Beeren, Fisch …)
  for (const [group, members] of Object.entries(INGREDIENT_GROUPS)) {
    if (['gemüse', 'obst', 'teig', 'milchprodukte', 'ei', 'kräuter', 'getreide'].includes(group)) continue;
    const gm = members.map(normalize);
    if (names.some((n) => gm.some((m) => n === m || n.split(' ').includes(m) || (m.length >= 5 && n.includes(m))))) {
      set.add(group.charAt(0).toUpperCase() + group.slice(1));
    }
  }

  // Ernährung
  if (ingredients.length > 0) {
    const nonVeg = [...NON_VEGETARIAN].map(normalize);
    const nonVegan = [...NON_VEGAN].map(normalize);
    const plant = /hafer|mandel|soja|kokos|reis|dinkel|cashew|erbsen|pflanz|vegan|tofu|margarine/;
    const hasAny = (list: string[]) =>
      names.some((n) => !plant.test(n) && list.some((m) => n === m || n.split(' ').includes(m) || (m.length >= 5 && n.includes(m))));
    if (!hasAny(nonVeg)) {
      set.add('vegetarisch');
      if (!hasAny(nonVegan)) set.add('vegan');
    }
  }
  return [...set];
}

/** Hauptfunktion: OCR-Text → Rezeptentwurf. */
export function parseRecipeText(raw: string): RecipeDraft {
  const draft = emptyDraft();
  draft.sourceText = raw;
  const lines = cleanLines(raw);
  if (lines.length === 0) {
    if (raw.trim()) draft.title = 'Unbenanntes Rezept';
    return draft;
  }

  // 1) Zeiten & Portionen aus dem Gesamttext
  const times = extractLabeledTimes(lines.join('\n'));
  const pick = (kind: TimeMatch['kind']) => {
    const list = times.filter((t) => t.kind === kind).map((t) => t.minutes);
    return list.length ? list.reduce((a, b) => a + b, 0) : null;
  };
  draft.activeMinutes = pick('active');
  draft.passiveMinutes = pick('passive');
  const explicitTotal = pick('total');
  draft.servings = parseServings(lines.join('\n'));

  // 2) Titel
  const timeLineIdx = new Set<number>();
  lines.forEach((l, i) => {
    if (TIME_LABELS.some((t) => t.re.test(l)) && parseDurationMinutes(l) != null) timeLineIdx.add(i);
    if (/^(für|for|ergibt|reicht für|serves)\s*\d+/i.test(l) || /^\d+\s*(personen|portionen|servings)/i.test(l)) timeLineIdx.add(i);
  });
  let titleIdx = -1;
  for (let i = 0; i < Math.min(lines.length, 6); i++) {
    if (timeLineIdx.has(i)) continue;
    if (looksLikeTitle(lines[i])) {
      titleIdx = i;
      break;
    }
  }
  if (titleIdx === -1) {
    titleIdx = lines.findIndex((l, i) => !timeLineIdx.has(i) && !INGREDIENT_HEADER.test(l) && !STEP_HEADER.test(l));
  }
  draft.title = titleIdx >= 0 ? lines[titleIdx].replace(/[:.]+$/, '') : 'Unbenanntes Rezept';

  // 3) Zutaten und Schritte
  let section: 'unknown' | 'ingredients' | 'steps' = 'unknown';
  const ingredients: Ingredient[] = [];
  const steps: string[] = [];
  let pendingStep = '';
  const flushStep = () => {
    if (pendingStep.trim()) steps.push(pendingStep.trim());
    pendingStep = '';
  };

  for (let i = 0; i < lines.length; i++) {
    if (i === titleIdx || timeLineIdx.has(i)) continue;
    const line = lines[i];
    if (INGREDIENT_HEADER.test(line)) {
      flushStep();
      section = 'ingredients';
      continue;
    }
    if (STEP_HEADER.test(line)) {
      flushStep();
      section = 'steps';
      continue;
    }

    if (section === 'ingredients') {
      if (looksLikeStep(line) && !looksLikeIngredient(line)) {
        section = 'steps';
      } else {
        ingredients.push(parseIngredientLine(line));
        continue;
      }
    }
    if (section === 'steps') {
      if (/^\d{1,2}[.)]\s+/.test(line)) {
        flushStep();
        pendingStep = line.replace(/^\d{1,2}[.)]\s+/, '');
      } else if (/[.!?:]$/.test(pendingStep) || pendingStep === '') {
        flushStep();
        pendingStep = line;
      } else {
        pendingStep += ' ' + line; // OCR-Zeilenumbruch mitten im Satz
      }
      continue;
    }
    // unknown: zeilenweise raten
    if (looksLikeIngredient(line) && !looksLikeStep(line)) ingredients.push(parseIngredientLine(line));
    else if (looksLikeStep(line)) {
      section = 'steps';
      pendingStep = line.replace(/^\d{1,2}[.)]\s+/, '');
    } else if (line.length <= 40) ingredients.push(parseIngredientLine(line));
    else {
      section = 'steps';
      pendingStep = line;
    }
  }
  flushStep();

  draft.ingredients = ingredients.filter((i) => i.name.length > 0 || i.amount.length > 0);
  draft.steps = steps;

  // 4) Passive Zeit aus Schritten, falls nicht beschriftet
  if (draft.passiveMinutes == null) {
    const fromSteps = passiveMinutesFromSteps(steps);
    if (fromSteps > 0) draft.passiveMinutes = fromSteps;
  }
  // Wenn nur Gesamtzeit und passive Zeit bekannt: aktiv = Rest
  if (draft.activeMinutes == null && explicitTotal != null && draft.passiveMinutes != null && explicitTotal > draft.passiveMinutes) {
    draft.activeMinutes = explicitTotal - draft.passiveMinutes;
  }
  draft.totalMinutes = computeTotal(draft.activeMinutes, draft.passiveMinutes, explicitTotal);

  // 5) Kategorisierung
  const preliminaryKeywords = inferKeywords(draft.title, draft.ingredients, draft.steps, []);
  draft.mealTypes = inferMealTypes(draft.title, preliminaryKeywords, draft.ingredients, draft.steps);
  draft.keywords = inferKeywords(draft.title, draft.ingredients, draft.steps, draft.mealTypes);

  return draft;
}
