import type { MealType } from './types';

/**
 * Wissensbasis für Suche und automatische Kategorisierung.
 * Alles kleingeschrieben, ohne Umlaut-Normalisierung (die macht normalize()).
 */

/** Oberbegriff → Zutaten, die darunter fallen. Suche nach "käse" findet alle Mitglieder. */
export const INGREDIENT_GROUPS: Record<string, string[]> = {
  käse: [
    'käse', 'mozzarella', 'parmesan', 'gouda', 'emmentaler', 'feta', 'ricotta', 'mascarpone',
    'frischkäse', 'camembert', 'brie', 'cheddar', 'gorgonzola', 'bergkäse', 'ziegenkäse',
    'halloumi', 'pecorino', 'grana padano', 'raclette', 'hüttenkäse', 'quark', 'schafskäse',
    'blauschimmelkäse', 'gruyère', 'greyerzer', 'appenzeller', 'burrata', 'reibekäse', 'streukäse',
  ],
  beeren: [
    'beeren', 'blaubeeren', 'heidelbeeren', 'himbeeren', 'erdbeeren', 'brombeeren', 'johannisbeeren',
    'stachelbeeren', 'preiselbeeren', 'cranberries', 'holunderbeeren', 'waldbeeren',
  ],
  fleisch: [
    'fleisch', 'rind', 'rindfleisch', 'hackfleisch', 'hack', 'schwein', 'schweinefleisch', 'lamm',
    'kalb', 'steak', 'schnitzel', 'gulasch', 'braten', 'speck', 'schinken', 'wurst', 'bratwurst',
    'salami', 'chorizo', 'bacon', 'hähnchen', 'huhn', 'hühnchen', 'pute', 'truthahn', 'ente', 'geflügel',
    'filet', 'kotelett', 'rippchen', 'frikadellen',
  ],
  geflügel: ['hähnchen', 'huhn', 'hühnchen', 'pute', 'truthahn', 'ente', 'geflügel', 'hähnchenbrust', 'chicken'],
  fisch: [
    'fisch', 'lachs', 'thunfisch', 'forelle', 'kabeljau', 'seelachs', 'dorade', 'zander', 'hering',
    'makrele', 'sardinen', 'garnelen', 'shrimps', 'krabben', 'muscheln', 'meeresfrüchte', 'tintenfisch',
    'scampi', 'wolfsbarsch', 'rotbarsch', 'matjes',
  ],
  gemüse: [
    'gemüse', 'zucchini', 'aubergine', 'paprika', 'tomate', 'tomaten', 'gurke', 'karotte', 'karotten',
    'möhre', 'möhren', 'brokkoli', 'blumenkohl', 'spinat', 'kohl', 'weißkohl', 'rotkohl', 'wirsing',
    'grünkohl', 'lauch', 'zwiebel', 'zwiebeln', 'knoblauch', 'kürbis', 'sellerie', 'fenchel',
    'rote bete', 'spargel', 'erbsen', 'bohnen', 'mais', 'champignons', 'pilze', 'süßkartoffel',
    'kartoffel', 'kartoffeln', 'rosenkohl', 'mangold', 'artischocke', 'okra', 'pak choi', 'rucola',
    'salat', 'kopfsalat', 'feldsalat', 'radieschen', 'kohlrabi', 'pastinake', 'petersilienwurzel',
  ],
  kartoffeln: ['kartoffel', 'kartoffeln', 'süßkartoffel', 'süßkartoffeln', 'pommes', 'kartoffelpüree', 'gnocchi'],
  nudeln: [
    'nudeln', 'pasta', 'spaghetti', 'penne', 'tagliatelle', 'fusilli', 'lasagneplatten', 'lasagne',
    'makkaroni', 'rigatoni', 'farfalle', 'linguine', 'gnocchi', 'ravioli', 'tortellini', 'bandnudeln',
    'spätzle', 'reisnudeln', 'glasnudeln', 'udon', 'ramen', 'orecchiette', 'cannelloni',
  ],
  reis: ['reis', 'risotto', 'basmatireis', 'jasminreis', 'milchreis', 'sushireis', 'wildreis', 'risottoreis'],
  getreide: ['haferflocken', 'hafer', 'dinkel', 'quinoa', 'couscous', 'bulgur', 'hirse', 'polenta', 'grieß', 'buchweizen', 'müsli', 'granola'],
  hülsenfrüchte: ['linsen', 'kichererbsen', 'bohnen', 'kidneybohnen', 'weiße bohnen', 'erbsen', 'tofu', 'edamame', 'sojabohnen'],
  obst: [
    'obst', 'apfel', 'äpfel', 'birne', 'birnen', 'banane', 'bananen', 'orange', 'orangen', 'zitrone',
    'limette', 'mango', 'ananas', 'kiwi', 'pfirsich', 'aprikose', 'aprikosen', 'pflaume', 'pflaumen',
    'zwetschgen', 'kirsche', 'kirschen', 'trauben', 'weintrauben', 'melone', 'wassermelone', 'granatapfel',
    'feige', 'feigen', 'rhabarber', 'quitte', 'mandarine', 'grapefruit', 'papaya', 'maracuja', 'dattel', 'datteln',
    'beeren', 'blaubeeren', 'heidelbeeren', 'himbeeren', 'erdbeeren', 'brombeeren', 'johannisbeeren',
  ],
  nüsse: ['nüsse', 'walnüsse', 'haselnüsse', 'mandeln', 'cashews', 'cashewkerne', 'pistazien', 'erdnüsse', 'pekannüsse', 'macadamia', 'pinienkerne', 'kokos', 'kokosraspeln'],
  schokolade: ['schokolade', 'kakao', 'zartbitterschokolade', 'vollmilchschokolade', 'schokodrops', 'nutella', 'kuvertüre', 'schokostreusel'],
  ei: ['ei', 'eier', 'eigelb', 'eiweiß', 'eiklar'],
  milchprodukte: ['milch', 'sahne', 'schlagsahne', 'butter', 'joghurt', 'quark', 'buttermilch', 'crème fraîche', 'schmand', 'saure sahne', 'kondensmilch', 'kefir'],
  teig: ['mehl', 'hefe', 'backpulver', 'blätterteig', 'pizzateig', 'mürbeteig', 'hefeteig', 'filoteig', 'strudelteig', 'quark-öl-teig'],
  kräuter: ['basilikum', 'petersilie', 'thymian', 'rosmarin', 'oregano', 'dill', 'koriander', 'minze', 'schnittlauch', 'salbei', 'estragon', 'majoran', 'lorbeer', 'kerbel'],
  scharf: ['chili', 'chilischote', 'peperoni', 'jalapeño', 'cayennepfeffer', 'harissa', 'sriracha', 'tabasco', 'sambal'],
};

/** Synonyme/Schreibvarianten, die dasselbe meinen. */
export const SYNONYMS: string[][] = [
  ['blaubeeren', 'heidelbeeren', 'blaubeere', 'heidelbeere', 'blueberries', 'blueberry'],
  ['möhren', 'karotten', 'möhre', 'karotte', 'rüebli'],
  ['hackfleisch', 'hack', 'gehacktes', 'faschiertes'],
  ['sahne', 'rahm', 'schlagsahne', 'obers'],
  ['quark', 'topfen'],
  ['tomaten', 'tomate', 'paradeiser'],
  ['paprika', 'paprikaschote'],
  ['kartoffeln', 'kartoffel', 'erdäpfel'],
  ['nudeln', 'pasta', 'teigwaren'],
  ['pilze', 'champignons', 'schwammerl'],
  ['hähnchen', 'huhn', 'hühnchen', 'hendl', 'chicken', 'poulet'],
  ['kuchen', 'cake', 'torte'],
  ['nachspeise', 'nachtisch', 'dessert', 'süßspeise', 'süß'],
  ['frühstück', 'breakfast', 'brunch'],
  ['abendessen', 'abendbrot', 'dinner', 'abend'],
  ['mittag', 'mittagessen', 'lunch'],
  ['vorspeise', 'starter', 'appetizer', 'antipasti'],
  ['side-dish', 'beilage', 'beilagen', 'side dish', 'sidedish', 'side'],
  ['vegetarisch', 'veggie', 'fleischlos'],
  ['vegan', 'pflanzlich'],
  ['schnell', 'fix', 'einfach', 'quick'],
  ['auflauf', 'gratin', 'überbacken'],
  ['brot', 'bread', 'brötchen', 'semmel'],
  ['suppe', 'soup', 'eintopf'],
  ['salat', 'salad'],
  ['pfannkuchen', 'pancakes', 'palatschinken', 'eierkuchen', 'crêpes'],
  ['smoothie', 'shake'],
];

/**
 * Gerichte-Muster → Mahlzeit-Typen. Wird auf Titel + Keywords angewendet.
 * Reihenfolge egal, alle Treffer werden gesammelt.
 */
export const MEAL_RULES: { pattern: RegExp; meals: MealType[]; keyword?: string }[] = [
  { pattern: /smoothie|shake/i, meals: ['Frühstück', 'Nachspeise'], keyword: 'Smoothie' },
  { pattern: /porridge|haferbrei|overnight oats|müsli|granola|oats\b/i, meals: ['Frühstück'], keyword: 'Müsli' },
  { pattern: /pancake|pfannkuchen|waffel|crêpe|crepe|french toast|eierkuchen/i, meals: ['Frühstück', 'Nachspeise'], keyword: 'Pfannkuchen' },
  { pattern: /rührei|spiegelei|omelett|omelette|frühstück|breakfast|brunch/i, meals: ['Frühstück'] },
  { pattern: /kuchen|torte|cake|tarte|muffin|cupcake|brownie|cookie|kekse|plätzchen|gebäck|strudel|zimtschnecke|donut|scones?\b/i, meals: ['Nachspeise'], keyword: 'Kuchen & Gebäck' },
  { pattern: /dessert|nachtisch|nachspeise|pudding|mousse|creme\b|crème brûlée|tiramisu|panna cotta|eis\b|eiscreme|sorbet|parfait|kompott|crumble|trifle|cheesecake|käsekuchen|schokolade/i, meals: ['Nachspeise'], keyword: 'Dessert' },
  { pattern: /pizza|flammkuchen|calzone/i, meals: ['Mittag', 'Abendessen'], keyword: 'Pizza' },
  { pattern: /pasta|nudel|spaghetti|penne|lasagne|tagliatelle|gnocchi|ravioli|tortellini|spätzle|mac ?and ?cheese|carbonara|bolognese/i, meals: ['Mittag', 'Abendessen'], keyword: 'Pasta' },
  { pattern: /gratin|auflauf|überbacken/i, meals: ['Mittag', 'Abendessen', 'Side-dish'], keyword: 'Auflauf' },
  { pattern: /risotto|paella|reispfanne|curry|bowl\b|wok|pfanne\b|geschnetzeltes|gulasch|braten|schnitzel|steak|burger|wrap|tacos?|burrito|quesadilla|chili con carne|frikadellen|bratwurst|ragout|rouladen|hähnchen|lachs|fisch|filet/i, meals: ['Mittag', 'Abendessen'], keyword: 'Hauptgericht' },
  { pattern: /suppe|soup|eintopf|brühe|gazpacho|minestrone|ramen|pho\b/i, meals: ['Vorspeise', 'Mittag', 'Abendessen'], keyword: 'Suppe' },
  { pattern: /salat|salad|coleslaw|tabouleh|caprese/i, meals: ['Vorspeise', 'Side-dish', 'Mittag'], keyword: 'Salat' },
  { pattern: /bruschetta|antipasti|carpaccio|tapas|häppchen|fingerfood|vorspeise|starter|appetizer/i, meals: ['Vorspeise'], keyword: 'Vorspeise' },
  { pattern: /dip\b|hummus|guacamole|tzatziki|pesto|aioli|chutney|sauce|soße|dressing|relish|salsa/i, meals: ['Side-dish'], keyword: 'Dip & Sauce' },
  { pattern: /kartoffelpüree|püree|pommes|bratkartoffeln|ofenkartoffeln|rösti|knödel|klöße|reis\b|couscous|bulgur|polenta|quinoa|gemüsepfanne|ofengemüse|rotkohl|sauerkraut|beilage|side dish/i, meals: ['Side-dish'], keyword: 'Beilage' },
  { pattern: /brot\b|brötchen|baguette|focaccia|fladenbrot|naan|bagel|zopf|laugen/i, meals: ['Frühstück', 'Side-dish'], keyword: 'Brot' },
  { pattern: /marmelade|konfitüre|gelee|aufstrich|sirup|limonade|eistee|punsch|glühwein|cocktail|drink/i, meals: ['Frühstück', 'Nachspeise'], keyword: 'Getränk & Aufstrich' },
];

/** Zutaten/Titel-Muster → zusätzliche Keywords (Ernährung, Küche, Aufwand). */
export const KEYWORD_RULES: { pattern: RegExp; keyword: string }[] = [
  { pattern: /vegan/i, keyword: 'vegan' },
  { pattern: /vegetarisch|veggie/i, keyword: 'vegetarisch' },
  { pattern: /glutenfrei|gluten-frei/i, keyword: 'glutenfrei' },
  { pattern: /laktosefrei/i, keyword: 'laktosefrei' },
  { pattern: /low ?carb/i, keyword: 'low carb' },
  { pattern: /schnell|in \d{1,2} minuten|blitz/i, keyword: 'schnell' },
  { pattern: /italien|pizza|pasta|risotto|lasagne|bruschetta|tiramisu|gnocchi|pesto/i, keyword: 'italienisch' },
  { pattern: /asia|thai|curry|wok|sushi|ramen|teriyaki|kokosmilch|sojasauce|sojasoße|pho\b|udon/i, keyword: 'asiatisch' },
  { pattern: /mexik|tacos?|burrito|quesadilla|guacamole|salsa|chili con carne|tortilla/i, keyword: 'mexikanisch' },
  { pattern: /griech|feta|tzatziki|gyros|moussaka|souvlaki/i, keyword: 'griechisch' },
  { pattern: /franz|ratatouille|quiche|crêpe|crème|baguette|tarte/i, keyword: 'französisch' },
  { pattern: /spanisch|paella|tapas|tortilla española|gazpacho/i, keyword: 'spanisch' },
  { pattern: /indisch|masala|tikka|dal\b|naan|biryani|tandoori/i, keyword: 'indisch' },
  { pattern: /orient|hummus|falafel|tahini|couscous|tabouleh|shakshuka|baba ganoush/i, keyword: 'orientalisch' },
  { pattern: /ofen|backofen|backen|°c|grad\b/i, keyword: 'Ofen' },
  { pattern: /grill/i, keyword: 'Grill' },
  { pattern: /one ?pot|eintopf/i, keyword: 'One Pot' },
  { pattern: /meal ?prep|vorbereiten|vorkochen|einfrieren/i, keyword: 'Meal Prep' },
  { pattern: /kinder|familie/i, keyword: 'Familie' },
  { pattern: /weihnacht|advent|plätzchen|lebkuchen|glühwein/i, keyword: 'Weihnachten' },
  { pattern: /ostern|osterlamm/i, keyword: 'Ostern' },
  { pattern: /sommer|erfrischend|eiskalt/i, keyword: 'Sommer' },
  { pattern: /herbst|kürbis/i, keyword: 'Herbst' },
];

/** Zutaten, die auf Fleisch/Fisch hindeuten (für die vegetarisch-Erkennung). */
export const NON_VEGETARIAN = new Set([...INGREDIENT_GROUPS.fleisch, ...INGREDIENT_GROUPS.fisch, 'gelatine', 'gelatine', 'speckwürfel', 'brühwürfel']);
export const NON_VEGAN = new Set([...NON_VEGETARIAN, ...INGREDIENT_GROUPS.ei, ...INGREDIENT_GROUPS.milchprodukte, ...INGREDIENT_GROUPS.käse, 'honig']);

/** Kleinschreibung, Umlaute vereinheitlichen, Sonderzeichen raus. */
export function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .replace(/[^a-z0-9\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Liefert alle Begriffe, die dasselbe meinen wie `term` (inkl. term selbst), normalisiert. */
export function expandTerm(term: string): string[] {
  const t = normalize(term);
  const out = new Set<string>([t]);
  for (const group of SYNONYMS) {
    const g = group.map(normalize);
    if (g.some((w) => w === t || stemEquals(w, t))) g.forEach((w) => out.add(w));
  }
  for (const [name, members] of Object.entries(INGREDIENT_GROUPS)) {
    const n = normalize(name);
    if (n === t || stemEquals(n, t)) members.map(normalize).forEach((w) => out.add(w));
  }
  return [...out];
}

/** Grobes deutsches Stemming: Blaubeere/Blaubeeren, Tomate/Tomaten, Kartoffel/Kartoffeln. */
export function stem(w: string): string {
  let s = w;
  if (s.length > 5) s = s.replace(/(nen|en|er|es|se|n|e|s)$/, '');
  return s;
}

export function stemEquals(a: string, b: string): boolean {
  return stem(a) === stem(b);
}
