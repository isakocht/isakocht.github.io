import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import type { Recipe, RecipeDraft } from './types';

/**
 * Speicher im Browser (IndexedDB). Rezepte und Bilder liegen nur auf diesem Gerät.
 * Bilder werden als Blob gespeichert und über recipe.imageUri = "img:<id>" referenziert.
 */
interface Schema extends DBSchema {
  recipes: { key: string; value: Recipe; indexes: { title: string } };
  images: { key: string; value: { id: string; blob: Blob } };
}

let dbp: Promise<IDBPDatabase<Schema>> | null = null;

function db() {
  if (!dbp) {
    dbp = openDB<Schema>('rezeptbuch', 1, {
      upgrade(d) {
        const r = d.createObjectStore('recipes', { keyPath: 'id' });
        r.createIndex('title', 'title');
        d.createObjectStore('images', { keyPath: 'id' });
      },
    });
  }
  return dbp;
}

export function newId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export async function listRecipes(): Promise<Recipe[]> {
  const all = await (await db()).getAll('recipes');
  return all.sort((a, b) => a.title.localeCompare(b.title, 'de'));
}

export async function getRecipe(id: string): Promise<Recipe | undefined> {
  return (await db()).get('recipes', id);
}

export async function insertRecipe(draft: RecipeDraft): Promise<Recipe> {
  const now = Date.now();
  const recipe: Recipe = { ...draft, id: newId(), createdAt: now, updatedAt: now };
  await (await db()).put('recipes', recipe);
  return recipe;
}

export async function updateRecipe(id: string, draft: RecipeDraft): Promise<void> {
  const d = await db();
  const old = await d.get('recipes', id);
  if (old?.imageUri && old.imageUri !== draft.imageUri) await deleteImage(old.imageUri);
  await d.put('recipes', { ...draft, id, createdAt: old?.createdAt ?? Date.now(), updatedAt: Date.now() });
}

export async function deleteRecipe(id: string): Promise<void> {
  const d = await db();
  const old = await d.get('recipes', id);
  if (old?.imageUri) await deleteImage(old.imageUri);
  await d.delete('recipes', id);
}

export async function saveImage(blob: Blob): Promise<string> {
  const id = newId();
  await (await db()).put('images', { id, blob });
  return `img:${id}`;
}

export async function loadImage(ref: string | null): Promise<Blob | null> {
  if (!ref?.startsWith('img:')) return null;
  const row = await (await db()).get('images', ref.slice(4));
  return row?.blob ?? null;
}

export async function deleteImage(ref: string | null): Promise<void> {
  if (!ref?.startsWith('img:')) return;
  await (await db()).delete('images', ref.slice(4));
}

/** Alle Rezepte als JSON-Text (Bilder ausgenommen, die sind zu groß für eine Textdatei). */
export async function exportAll(): Promise<string> {
  const recipes = (await listRecipes()).map((r) => ({ ...r, imageUri: null }));
  return JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), recipes }, null, 2);
}

export async function importAll(json: string): Promise<number> {
  const data = JSON.parse(json) as { recipes?: Recipe[] };
  if (!Array.isArray(data.recipes)) throw new Error('Das ist keine Rezeptbuch-Backup-Datei.');
  const d = await db();
  const tx = d.transaction('recipes', 'readwrite');
  let n = 0;
  for (const r of data.recipes) {
    if (!r.id || typeof r.title !== 'string') continue;
    const existing = await tx.store.get(r.id);
    await tx.store.put({
      id: r.id,
      title: r.title,
      ingredients: r.ingredients ?? [],
      steps: r.steps ?? [],
      activeMinutes: r.activeMinutes ?? null,
      passiveMinutes: r.passiveMinutes ?? null,
      totalMinutes: r.totalMinutes ?? null,
      servings: r.servings ?? null,
      mealTypes: r.mealTypes ?? [],
      keywords: r.keywords ?? [],
      sourceText: r.sourceText ?? '',
      imageUri: existing?.imageUri ?? null,
      notes: r.notes ?? '',
      createdAt: r.createdAt ?? Date.now(),
      updatedAt: Date.now(),
    });
    n++;
  }
  await tx.done;
  return n;
}

/** Bittet den Browser, die Daten nicht bei Speicherknappheit zu löschen. */
export async function requestPersistentStorage(): Promise<boolean> {
  try {
    if (navigator.storage?.persist) return await navigator.storage.persist();
  } catch {
    /* egal */
  }
  return false;
}
