import { parseRecipeText, parseDurationMinutes, parseIngredientLine, parseServings } from '../src/lib/parser';
import { searchRecipes, mealTypeFromTerm, groupByLetter } from '../src/lib/search';
import { Recipe } from '../src/lib/types';

const GRATIN = `Kartoffelgratin
Für 4 Personen
Zubereitung: 20 Min. | Backzeit: 45 Min.

Zutaten
1 kg Kartoffeln
250 ml Sahne
150 ml Milch
2 Knoblauchzehen
150 g Gouda, gerieben
Salz, Pfeffer, Muskat
1 EL Butter

Zubereitung
1. Kartoffeln schälen und in dünne Scheiben hobeln.
2. Sahne, Milch, gepressten Knoblauch, Salz, Pfeffer und Muskat
verrühren.
3. Kartoffeln in eine gebutterte Form schichten, Sahnemischung
darübergießen und mit Käse bestreuen.
4. Bei 180 °C ca. 45 Minuten goldbraun backen.`;

const PIZZA = `Pizza Margherita
Arbeitszeit ca. 30 Minuten, Ruhezeit 1 Std
Zutaten für 2 Pizzen
500 g Mehl
1 Pck. Trockenhefe
300 ml Wasser
1 TL Salz
400 g Tomaten (Dose)
250 g Mozzarella
Basilikum
Aus Mehl, Hefe, Wasser und Salz einen Teig kneten und 1 Stunde gehen lassen. Ausrollen, mit Tomaten
belegen, Mozzarella darauf verteilen und bei 250 Grad 12 Minuten backen. Mit Basilikum servieren.`;

const SMOOTHIE = `Blaubeer-Smoothie
1 Banane
150 g Heidelbeeren
200 ml Hafermilch
1 EL Haferflocken
Alles in den Mixer geben und cremig pürieren.`;

const CAKE = `Heidelbeer-Käsekuchen

Zubereitungszeit: 30 Minuten
Backzeit: 60 Minuten
Kühlzeit: 4 Stunden

Für den Boden:
200 g Butterkekse
100 g Butter

Für die Füllung:
750 g Quark
200 g Frischkäse
150 g Zucker
3 Eier
1 Pck. Vanillepudding
250 g Blaubeeren

Kekse zerbröseln und mit geschmolzener Butter vermischen. In eine Springform drücken.
Quark, Frischkäse, Zucker, Eier und Puddingpulver verrühren, Blaubeeren unterheben.
Bei 160 °C 60 Minuten backen. Im Kühlschrank mindestens 4 Stunden kühlen.`;

function mk(text: string): Recipe {
  const d = parseRecipeText(text);
  return { ...d, id: d.title, createdAt: 0, updatedAt: 0 };
}

describe('parseDurationMinutes', () => {
  it('parses common formats', () => {
    expect(parseDurationMinutes('45 Min.')).toBe(45);
    expect(parseDurationMinutes('1 Std 30 Min')).toBe(90);
    expect(parseDurationMinutes('1,5 Stunden')).toBe(90);
    expect(parseDurationMinutes('2 h')).toBe(120);
    expect(parseDurationMinutes('ca. 10-15 Minuten')).toBe(15);
    expect(parseDurationMinutes('über Nacht')).toBe(480);
    expect(parseDurationMinutes('kein Wert')).toBeNull();
  });
});

describe('parseIngredientLine', () => {
  it('splits amount and name', () => {
    expect(parseIngredientLine('250 ml Sahne')).toEqual({ amount: '250 ml', name: 'Sahne' });
    expect(parseIngredientLine('150 g Gouda, gerieben')).toEqual({ amount: '150 g', name: 'Gouda, gerieben' });
    expect(parseIngredientLine('Salz, Pfeffer, Muskat')).toEqual({ amount: '', name: 'Salz, Pfeffer, Muskat' });
    expect(parseIngredientLine('1/2 TL Zimt')).toEqual({ amount: '1/2 TL', name: 'Zimt' });
    expect(parseIngredientLine('½ Zitrone')).toEqual({ amount: '1/2', name: 'Zitrone' });
    expect(parseIngredientLine('1 Pck. Trockenhefe')).toEqual({ amount: '1 Pck', name: 'Trockenhefe' });
    expect(parseIngredientLine('etwas Öl')).toEqual({ amount: 'etwas', name: 'Öl' });
  });
});

describe('parseServings', () => {
  it('finds servings', () => {
    expect(parseServings('Für 4 Personen')).toBe('4 Personen');
    expect(parseServings('ergibt 12 Stück')).toBe('12 Stück');
    expect(parseServings('Zutaten für 2 Pizzen')).toBe('2 Portionen');
  });
});

describe('parseRecipeText', () => {
  it('parses a structured recipe (Gratin)', () => {
    const r = parseRecipeText(GRATIN);
    expect(r.title).toBe('Kartoffelgratin');
    expect(r.servings).toBe('4 Personen');
    expect(r.activeMinutes).toBe(20);
    expect(r.passiveMinutes).toBe(45);
    expect(r.totalMinutes).toBe(65);
    expect(r.ingredients.map((i) => i.name)).toEqual(
      expect.arrayContaining(['Kartoffeln', 'Sahne', 'Milch', 'Knoblauchzehen', 'Gouda, gerieben', 'Salz, Pfeffer, Muskat', 'Butter']),
    );
    expect(r.ingredients).toHaveLength(7);
    expect(r.steps).toHaveLength(4);
    expect(r.steps[1]).toMatch(/Muskat verrühren\.$/);
    expect(r.mealTypes).toEqual(expect.arrayContaining(['Abendessen', 'Side-dish']));
    expect(r.keywords).toEqual(expect.arrayContaining(['Käse', 'Kartoffeln', 'vegetarisch', 'Ofen']));
    expect(r.keywords).not.toContain('vegan');
  });

  it('parses a loosely formatted recipe (Pizza)', () => {
    const r = parseRecipeText(PIZZA);
    expect(r.title).toBe('Pizza Margherita');
    expect(r.activeMinutes).toBe(30);
    expect(r.passiveMinutes).toBe(60);
    expect(r.totalMinutes).toBe(90);
    expect(r.ingredients.length).toBeGreaterThanOrEqual(7);
    expect(r.steps.length).toBeGreaterThanOrEqual(1);
    expect(r.mealTypes).toEqual(expect.arrayContaining(['Mittag', 'Abendessen']));
    expect(r.keywords).toEqual(expect.arrayContaining(['Pizza', 'italienisch', 'Käse']));
  });

  it('parses a recipe without any headers (Smoothie)', () => {
    const r = parseRecipeText(SMOOTHIE);
    expect(r.title).toBe('Blaubeer-Smoothie');
    expect(r.ingredients).toHaveLength(4);
    expect(r.steps).toHaveLength(1);
    expect(r.mealTypes).toEqual(expect.arrayContaining(['Frühstück', 'Nachspeise']));
    expect(r.keywords).toEqual(expect.arrayContaining(['Smoothie', 'Beeren', 'vegan']));
    expect(r.totalMinutes).toBeNull();
  });

  it('derives passive time from steps when labeled and sums multiple labels (Cake)', () => {
    const r = parseRecipeText(CAKE);
    expect(r.title).toBe('Heidelbeer-Käsekuchen');
    expect(r.activeMinutes).toBe(30);
    expect(r.passiveMinutes).toBe(300); // 60 backen + 240 kühlen
    expect(r.totalMinutes).toBe(330);
    expect(r.ingredients).toHaveLength(8);
    expect(r.mealTypes).toEqual(expect.arrayContaining(['Nachspeise', 'Backen']));
    expect(r.keywords).toEqual(expect.arrayContaining(['Kuchen & Gebäck', 'Beeren', 'Käse']));
  });

  it('never crashes on garbage', () => {
    expect(parseRecipeText('').title).toBe('');
    expect(parseRecipeText('   \n\n  ').title).toBe('');
    expect(parseRecipeText('12').title).toBe('Unbenanntes Rezept');
  });
});

describe('searchRecipes', () => {
  const all = [mk(GRATIN), mk(PIZZA), mk(SMOOTHIE), mk(CAKE)];

  it('"Abendessen Käse" finds Pizza and Gratin, not the smoothie', () => {
    const titles = searchRecipes(all, 'Abendessen Käse').map((r) => r.title);
    expect(titles).toEqual(expect.arrayContaining(['Kartoffelgratin', 'Pizza Margherita']));
    expect(titles).not.toContain('Blaubeer-Smoothie');
  });

  it('"Blaubeeren" finds smoothie and cake (via Heidelbeeren synonym)', () => {
    const titles = searchRecipes(all, 'Blaubeeren').map((r) => r.title);
    expect(titles).toEqual(expect.arrayContaining(['Blaubeer-Smoothie', 'Heidelbeer-Käsekuchen']));
    expect(titles).toHaveLength(2);
  });

  it('"Nachtisch Beeren" finds the dessert-type recipes', () => {
    const titles = searchRecipes(all, 'Nachtisch Beeren').map((r) => r.title);
    expect(titles).toEqual(expect.arrayContaining(['Blaubeer-Smoothie', 'Heidelbeer-Käsekuchen']));
  });

  it('"Beilage" finds the gratin', () => {
    expect(searchRecipes(all, 'Beilage').map((r) => r.title)).toContain('Kartoffelgratin');
  });

  it('empty query returns everything, filters work', () => {
    expect(searchRecipes(all, '')).toHaveLength(4);
    expect(searchRecipes(all, '', { mealTypes: ['Frühstück'] }).map((r) => r.title)).toEqual(['Blaubeer-Smoothie']);
    expect(searchRecipes(all, '', { keyword: 'Pizza' }).map((r) => r.title)).toEqual(['Pizza Margherita']);
  });

  it('favorites filter and "Backen" category', () => {
    const fav = all.map((r) => ({ ...r, favorite: r.title === 'Pizza Margherita' }));
    expect(searchRecipes(fav, '', { favoritesOnly: true }).map((r) => r.title)).toEqual(['Pizza Margherita']);
    expect(searchRecipes(all, 'backen').map((r) => r.title)).toEqual(expect.arrayContaining(['Heidelbeer-Käsekuchen', 'Pizza Margherita', 'Kartoffelgratin']));
    expect(searchRecipes(all, '', { mealTypes: ['Backen'] }).map((r) => r.title)).toContain('Heidelbeer-Käsekuchen');
    expect(parseRecipeText('Notiz ohne Inhalt').mealTypes).toEqual(['Sonstiges']);
  });

  it('mealTypeFromTerm', () => {
    expect(mealTypeFromTerm('dessert')).toBe('Nachspeise');
    expect(mealTypeFromTerm('dinner')).toBe('Abendessen');
    expect(mealTypeFromTerm('beilage')).toBe('Side-dish');
    expect(mealTypeFromTerm('käse')).toBeNull();
  });

  it('groups by letter', () => {
    const g = groupByLetter(all);
    expect(g.map((x) => x.letter)).toEqual(['B', 'H', 'K', 'P']);
  });
});
